package com.example.prepin;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
