import 'package:flutter/material.dart';
import 'package:prepin/profilepage.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class EditProfilePage extends StatefulWidget {
  final String email; // User's email passed from previous screen (non-editable)
  const EditProfilePage({Key? key, required this.email}) : super(key: key);

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  // Controllers for each field
  final TextEditingController _fullNameController = TextEditingController(text: '');
  final TextEditingController _nickNameController = TextEditingController(text: '');
  final TextEditingController _emailController = TextEditingController(text: '');
  final TextEditingController _phoneController = TextEditingController(text: '');

  // Example dropdown lists
  final List<String> _countries = ['India', 'USA', 'UK', 'Canada'];
  final List<String> _genres = ['Male', 'Female', 'Other'];

  // Selected values
  String? _selectedCountry = 'India';
  String? _selectedGenre = 'Female';

  // Base URL for your API endpoints – adjust as needed
  final String _baseUrl = "http://192.168.185.251:80/API/";

  @override
  void initState() {
    super.initState();
    // Prefill the non-editable email from the widget's parameter.
    _emailController.text = widget.email;
    _fetchProfileData();
  }

  // Fetch profile details from the backend using the provided email
  Future<void> _fetchProfileData() async {
    final url = Uri.parse("$_baseUrl" + "get_profile.php?email_address=${widget.email}");
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        // Expecting keys: "name", "nick_name", "email_address", "phone_number", "country", "genre"
        setState(() {
          if (data["name"] != null) {
            _fullNameController.text = data["name"];
          }
          if (data["nick_name"] != null) {
            _nickNameController.text = data["nick_name"];
          }
          if (data["email_address"] != null) {
            _emailController.text = data["email_address"];
          }
          if (data["phone_number"] != null && data["phone_number"].toString().trim().isNotEmpty) {
            _phoneController.text = data["phone_number"];
          } else {
            _phoneController.text = "+01 000 000 000";
          }
          if (data["country"] != null) {
            _selectedCountry = data["country"];
          }
          if (data["genre"] != null) {
            _selectedGenre = data["genre"];
          }
        });
      } else {
        debugPrint("Error fetching profile data: ${response.statusCode}");
      }
    } catch (e) {
      debugPrint("Error loading profile data: $e");
    }
  }

  // Submit the updated profile data to the backend
  Future<void> _submitProfile() async {
    final fullName = _fullNameController.text.trim();
    final nickName = _nickNameController.text.trim();
    final email = _emailController.text.trim(); // Non-editable
    final phone = _phoneController.text.trim();
    final country = _selectedCountry;
    final genre = _selectedGenre;

    if (email.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text("Email is required.")));
      return;
    }

    final url = Uri.parse("$_baseUrl" + "edit_profile.php");
    try {
      final response = await http.post(url, body: {
        'name': fullName,
        'nick_name': nickName,
        'phone_number': phone,
        'country': country ?? '',
        'genre': genre ?? '',
        'email_address': email,
      });

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(data["message"] ?? "Profile updated successfully.")));
        // After a successful update, navigate back to the Profile page.
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const ProfilePage()),
        );
      } else {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text("Error updating profile.")));
      }
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text("Error: $e")));
    }
  }

  // Back navigation without a bottom navigation bar
  void _goBack() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const ProfilePage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      // Transparent AppBar with back arrow
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: _goBack,
        ),
        centerTitle: true,
        title: const Text(
          'Edit Profile',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87),
        ),
      ),
      body: Stack(
        children: [
          // Full background image
          SizedBox.expand(
            child: Image.asset(
              'assets/insidebg.png', // Ensure this asset is declared in pubspec.yaml
              fit: BoxFit.cover,
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  minHeight: MediaQuery.of(context).size.height -
                      MediaQuery.of(context).padding.top -
                      kToolbarHeight,
                ),
                child: IntrinsicHeight(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const SizedBox(height: 80), // Spacing below the AppBar
                      // Full Name field
                      TextField(
                        controller: _fullNameController,
                        style: const TextStyle(fontSize: 14, color: Colors.black87),
                        decoration: InputDecoration(
                          labelText: 'Full Name',
                          labelStyle: const TextStyle(color: Colors.black54),
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.0)),
                        ),
                      ),
                      const SizedBox(height: 16),
                      // Nick Name field
                      TextField(
                        controller: _nickNameController,
                        style: const TextStyle(fontSize: 14, color: Colors.black87),
                        decoration: InputDecoration(
                          labelText: 'Last Name',
                          labelStyle: const TextStyle(color: Colors.black54),
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.0)),
                        ),
                      ),
                      const SizedBox(height: 16),
                      // Email field (non-editable)
                      TextField(
                        controller: _emailController,
                        readOnly: true,
                        style: const TextStyle(fontSize: 14, color: Colors.black87),
                        decoration: InputDecoration(
                          labelText: 'Email',
                          labelStyle: const TextStyle(color: Colors.black54),
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.0)),
                        ),
                        keyboardType: TextInputType.emailAddress,
                      ),
                      const SizedBox(height: 16),
                      // Phone Number field
                      TextField(
                        controller: _phoneController,
                        style: const TextStyle(fontSize: 14, color: Colors.black87),
                        decoration: InputDecoration(
                          labelText: 'Phone Number',
                          labelStyle: const TextStyle(color: Colors.black54),
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.0)),
                        ),
                        keyboardType: TextInputType.phone,
                      ),
                      const SizedBox(height: 16),
                      // Country (dropdown)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(8.0),
                          border: Border.all(color: Colors.grey.shade300),
                        ),
                        child: DropdownButtonFormField<String>(
                          decoration: const InputDecoration(border: InputBorder.none),
                          value: _selectedCountry,
                          items: _countries.map((country) {
                            return DropdownMenuItem<String>(
                              value: country,
                              child: Text(country),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                              _selectedCountry = value;
                            });
                          },
                          icon: const Icon(Icons.arrow_drop_down),
                          iconSize: 24,
                          style: const TextStyle(color: Colors.black87, fontSize: 14),
                          dropdownColor: Colors.white,
                          hint: const Text('Select Country'),
                        ),
                      ),
                      const SizedBox(height: 16),
                      // Genre (dropdown)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(8.0),
                          border: Border.all(color: Colors.grey.shade300),
                        ),
                        child: DropdownButtonFormField<String>(
                          decoration: const InputDecoration(border: InputBorder.none),
                          value: _selectedGenre,
                          items: _genres.map((genre) {
                            return DropdownMenuItem<String>(
                              value: genre,
                              child: Text(genre),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                              _selectedGenre = value;
                            });
                          },
                          icon: const Icon(Icons.arrow_drop_down),
                          iconSize: 24,
                          style: const TextStyle(color: Colors.black87, fontSize: 14),
                          dropdownColor: Colors.white,
                          hint: const Text('Select Genre'),
                        ),
                      ),
                      const SizedBox(height: 24),
                      // Submit button
                      SizedBox(
                        width: double.infinity,
                        height: 48,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.black,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8.0)),
                          ),
                          onPressed: _submitProfile,
                          child: const Text('SUBMIT',
                              style: TextStyle(color: Colors.white, fontSize: 16)),
                        ),
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
