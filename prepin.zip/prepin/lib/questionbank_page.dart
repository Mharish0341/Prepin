import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class QuestionBankPage extends StatefulWidget {
  final String pageTitle;
  final String category;
  final String questionType; // For Technical category; otherwise ignored

  const QuestionBankPage({
    Key? key,
    required this.pageTitle,
    required this.category,
    required this.questionType,
  }) : super(key: key);

  @override
  State<QuestionBankPage> createState() => _QuestionBankPageState();
}

class _QuestionBankPageState extends State<QuestionBankPage> {
  bool _isLoading = false;
  String _errorMessage = '';
  List<dynamic> _allQuestions = [];

  int _currentPage = 1;
  final int _pageSize = 10;

  final Uri _questionsUrl = Uri.parse(
    'http://192.168.185.251:80/API/get_questions_by_category_cardtitle.php',
  );

  List<dynamic> get _currentPageQuestions {
    final startIndex = (_currentPage - 1) * _pageSize;
    final endIndex = startIndex + _pageSize;
    if (startIndex >= _allQuestions.length) return [];
    return _allQuestions.sublist(startIndex, endIndex.clamp(0, _allQuestions.length));
  }

  int get totalQuestions => _allQuestions.length;
  int get totalPages => (totalQuestions / _pageSize).ceil();

  @override
  void initState() {
    super.initState();
    _fetchAllQuestions();
  }

  Future<void> _fetchAllQuestions() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
      _allQuestions.clear();
      _currentPage = 1;
    });

    try {
      // Build the question_type param for the POST
      String questionTypeParam;
      if (widget.category == 'Technical') {
        questionTypeParam = widget.questionType.isNotEmpty ? widget.questionType : '';
      } else if (widget.category == 'Aptitude & Verbal') {
        questionTypeParam = 'MCQ';
      } else {
        // Managerial & HR Interview
        questionTypeParam = 'Q/A';
      }

      final response = await http.post(
        _questionsUrl,
        body: {
          'category': widget.category,
          'card_title': widget.pageTitle,
          'question_type': questionTypeParam,
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data is List) {
          setState(() {
            _allQuestions = data;
            _isLoading = false;
          });
        } else if (data is Map && data.containsKey('message')) {
          setState(() {
            _errorMessage = data['message'];
            _isLoading = false;
          });
        } else {
          setState(() {
            _errorMessage = 'Unknown response format.';
            _isLoading = false;
          });
        }
      } else {
        setState(() {
          _errorMessage = 'Server error: ${response.statusCode}';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Exception: $e';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final startIndex = (_currentPage - 1) * _pageSize + 1;
    final endIndex = startIndex + _currentPageQuestions.length - 1;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: Text(
          widget.pageTitle,
          style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/insidebg.png'),
            fit: BoxFit.cover,
          ),
        ),
        child: SafeArea(
          top: true,
          child: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _errorMessage.isNotEmpty
              ? Center(child: Text(_errorMessage))
              : Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Text(
                  'Questions $startIndex - $endIndex of $totalQuestions',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: _currentPageQuestions.length,
                  itemBuilder: (context, index) {
                    final q = _currentPageQuestions[index];
                    return _buildQuestionItem(q);
                  },
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextButton(
                    onPressed: _currentPage > 1
                        ? () => setState(() => _currentPage--)
                        : null,
                    child: const Text('Previous'),
                  ),
                  Text('Page $_currentPage of $totalPages'),
                  TextButton(
                    onPressed: _currentPage < totalPages
                        ? () => setState(() => _currentPage++)
                        : null,
                    child: const Text('Next'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildQuestionItem(Map<String, dynamic> question) {
    final questionText = question['question_text'] ?? 'No question text';
    final answer = question['answer'] ?? '';

    // Determine display type:
    // • Technical + MCQ → MCQ style
    // • Technical + Q/A → Q/A style
    // • Aptitude & Verbal → MCQ style
    // • Managerial & HR Interview → Q/A style
    final bool isMCQ = (widget.category == 'Technical' && widget.questionType == 'MCQ') ||
        widget.category == 'Aptitude & Verbal';

    if (isMCQ) {
      final optionA = question['option_a'] ?? '';
      final optionB = question['option_b'] ?? '';
      final optionC = question['option_c'] ?? '';
      final optionD = question['option_d'] ?? '';
      final correctAnswer = question['correct_answer'] ?? '';
      return Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.9),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(questionText, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text('A) $optionA'),
            Text('B) $optionB'),
            Text('C) $optionC'),
            Text('D) $optionD'),
            const SizedBox(height: 6),
            Text('Answer: $correctAnswer', style: const TextStyle(color: Colors.green)),
          ],
        ),
      );
    } else {
      // Q/A style for Technical Q/A, Managerial & HR Interview
      return Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.9),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(questionText, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(answer, style: const TextStyle(color: Colors.blue)),
          ],
        ),
      );
    }
  }
}
