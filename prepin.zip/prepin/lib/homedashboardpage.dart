import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:prepin/preparation.dart';
import 'package:prepin/profilepage.dart';
import 'AiMockInterviewPage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

/// Removes both scrollbar and overscroll glow
class NoScrollbarBehavior extends ScrollBehavior {
  @override
  Widget buildOverscrollIndicator(
      BuildContext context,
      Widget child,
      ScrollableDetails details,
      ) {
    return child; // No glow
  }

  @override
  Widget buildScrollbar(
      BuildContext context,
      Widget child,
      ScrollableDetails details,
      ) {
    return child; // No scrollbar
  }
}

class HomeAndDashboardPage extends StatefulWidget {
  const HomeAndDashboardPage({Key? key}) : super(key: key);

  @override
  State<HomeAndDashboardPage> createState() => _HomeAndDashboardPageState();
}

class _HomeAndDashboardPageState extends State<HomeAndDashboardPage> {
  // Bottom nav
  int _currentIndex = 0;

  // Data
  int _totalQuestions = 0;
  double _accuracyRate = 0.0;
  int _streak = 0;
  List<dynamic> _recentActivities = [];
  String _username = "User";
  String? _avatarUrl;

  // Carousel: Declare _pageController and _currentSlide only once
  final PageController _pageController = PageController();
  int _currentSlide = 0; // 0 => AI Mock, 1 => Preparation

  // Base URL for API endpoints
  final String _baseUrl = "http://192.168.185.251:80/API/";

  @override
  void initState() {
    super.initState();
    _fetchUserInfo();
    _fetchProgressData();

    // Listen for page changes (to update dash indicator)
    _pageController.addListener(() {
      final page = _pageController.page?.round() ?? 0;
      if (page != _currentSlide) {
        setState(() {
          _currentSlide = page;
        });
      }
    });

    // Make system nav bar white
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark,
        systemNavigationBarColor: Colors.white,
        systemNavigationBarIconBrightness: Brightness.dark,
      ),
    );
    // Edge-to-edge on newer Android
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  }

  // Fetch user info using get_user.php
  Future<void> _fetchUserInfo() async {
    final prefs = await SharedPreferences.getInstance();
    final email = prefs.getString('email');
    if (email == null) return;

    final url = Uri.parse("$_baseUrl" + "get_user.php?email_address=$email");

    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data is Map) {
          setState(() {
            if (data["username"] != null) {
              _username = data["username"];
            }
            // Update avatar URL: if the returned value doesn't start with "http", prepend base URL.
            if (data["avatar"] != null) {
              String avatar = data["avatar"];
              if (!avatar.startsWith("http")) {
                avatar = _baseUrl + avatar;
              }
              _avatarUrl = avatar;
            }
          });
        }
      }
    } catch (e) {
      debugPrint("Error fetching user info: $e");
    }
  }

  // Fetch progress data
  Future<void> _fetchProgressData() async {
    final prefs = await SharedPreferences.getInstance();
    final email = prefs.getString('email');
    if (email == null) return;

    final url = Uri.parse("$_baseUrl" + "get_progress.php?email_address=$email");

    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data is! List) {
          setState(() {
            _totalQuestions = 0;
            _accuracyRate = 0.0;
            _streak = 0;
            _recentActivities = [];
          });
          return;
        }

        int totalQs = 0;
        double totalScore = 0;
        final timestamps = <DateTime>[];

        for (var attempt in data) {
          final q = (attempt['total_questions'] ?? 0) as int;
          final s = (attempt['score'] ?? 0) as num;
          totalQs += q;
          totalScore += s;

          if (attempt['timestamp'] != null) {
            final tsStr = attempt['timestamp'].toString().replaceFirst(' ', 'T');
            try {
              timestamps.add(DateTime.parse(tsStr));
            } catch (_) {}
          }
        }

        double accuracy = 0.0;
        if (totalQs > 0) {
          accuracy = (totalScore / totalQs) * 100.0;
        }

        // Compute streak
        int streak = 0;
        final uniqueDays = <DateTime>{};
        for (var dt in timestamps) {
          uniqueDays.add(DateTime(dt.year, dt.month, dt.day));
        }
        final sortedDays = uniqueDays.toList()..sort((a, b) => b.compareTo(a));
        if (sortedDays.isNotEmpty) {
          streak = 1;
          DateTime current = sortedDays.first;
          for (int i = 1; i < sortedDays.length; i++) {
            if (current.difference(sortedDays[i]).inDays == 1) {
              streak++;
              current = sortedDays[i];
            } else {
              break;
            }
          }
        }

        // Sort attempts descending
        data.sort((a, b) {
          DateTime dtA = DateTime.tryParse(a['timestamp'].toString().replaceFirst(' ', 'T')) ?? DateTime.now();
          DateTime dtB = DateTime.tryParse(b['timestamp'].toString().replaceFirst(' ', 'T')) ?? DateTime.now();
          return dtB.compareTo(dtA);
        });

        final recentCount = data.length > 4 ? 4 : data.length;
        final recentData = data.sublist(0, recentCount);

        setState(() {
          _totalQuestions = totalQs;
          _accuracyRate = accuracy;
          _streak = streak;
          _recentActivities = recentData;
        });
      }
    } catch (e) {
      debugPrint("Error fetching progress: $e");
      setState(() {
        _totalQuestions = 0;
        _accuracyRate = 0.0;
        _streak = 0;
        _recentActivities = [];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true, // background behind bottom nav
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          // Fullscreen background
          Positioned.fill(
            child: Image.asset(
              'assets/insidebg.png',
              fit: BoxFit.cover,
            ),
          ),
          // Main scrollable content
          SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: EdgeInsets.only(
              top: MediaQuery.of(context).padding.top + 20,
              left: 16,
              right: 16,
              bottom: kBottomNavigationBarHeight,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Greeting + avatar
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Hi, $_username',
                            style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),
                          const SizedBox(height: 4),
                          const Text(
                            "Let's start preparing",
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.black54,
                            ),
                          ),
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const ProfilePage()),
                        );
                      },
                      child: CircleAvatar(
                        radius: 25,
                        backgroundColor: Colors.transparent,
                        backgroundImage: _avatarUrl != null
                            ? NetworkImage(_avatarUrl!)
                            : const AssetImage('assets/avatar.png') as ImageProvider,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                // 2-slide carousel with dash indicator
                _buildSlider(),
                const SizedBox(height: 20),
                // Performance Overview
                Text(
                  'Performance Overview',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey.shade800,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _buildOverviewItem('$_totalQuestions Qs', 'Total Questions'),
                    _buildOverviewItem('${_accuracyRate.toStringAsFixed(0)}%', 'Accuracy Rate'),
                    _buildOverviewItem('$_streak Days', 'Streak'),
                  ],
                ),
                const SizedBox(height: 20),
                // Recent Activity
                Text(
                  'Recent Activity',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey.shade800,
                  ),
                ),
                Container(
                  height: 270,
                  child: _recentActivities.isNotEmpty
                      ? ScrollConfiguration(
                    behavior: NoScrollbarBehavior(),
                    child: ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      itemCount: _recentActivities.length,
                      itemBuilder: (context, index) {
                        final attempt = _recentActivities[index];
                        final roundName = attempt['round_type'] ?? "Unknown Round";
                        final questionType = attempt['question_type'] ?? "";
                        final totalQs = attempt['total_questions'] ?? 0;
                        final score = attempt['score'] ?? 0;

                        final questionsLabel = "$totalQs Question";
                        final scoreStr = "$score/$totalQs";

                        String line2 = questionsLabel;
                        if (questionType.isNotEmpty) {
                          line2 += " • $questionType";
                        }

                        final colors = [
                          Colors.orange,
                          Colors.blue,
                          Colors.green,
                          Colors.purple
                        ];
                        final color = colors[index % colors.length];

                        return Container(
                          margin: const EdgeInsets.only(bottom: 12),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(8),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.shade300,
                                blurRadius: 6,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Row(
                            children: [
                              CircleAvatar(
                                radius: 18,
                                backgroundColor: color.withOpacity(0.2),
                                child: Text(
                                  (index + 1).toString(),
                                  style: TextStyle(
                                    color: color,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      roundName,
                                      style: const TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black87,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      line2,
                                      style: const TextStyle(
                                        fontSize: 12,
                                        color: Colors.black54,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Text(
                                scoreStr,
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: color,
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  )
                      : ScrollConfiguration(
                    behavior: NoScrollbarBehavior(),
                    child: ListView(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      children: _buildNoActivityPlaceholder(),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      // White bottom nav
      bottomNavigationBar: Container(
        color: Colors.white,
        child: BottomNavigationBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          type: BottomNavigationBarType.fixed,
          currentIndex: _currentIndex,
          selectedItemColor: Colors.blue,
          unselectedItemColor: Colors.black,
          onTap: (index) {
            setState(() {
              _currentIndex = index;
            });
            switch (index) {
              case 0:
              // Already home
                break;
              case 1:
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const PreparationPage()),
                );
                break;
              case 2:
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const AiMockInterviewPage()),
                );
                break;
              case 3:
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ProfilePage()),
                );
                break;
            }
          },
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.home_outlined),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.menu_book_outlined),
              label: 'Preparation',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.smart_toy_outlined),
              label: 'AI Mock',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person_outline),
              label: 'Profile',
            ),
          ],
        ),
      ),
    );
  }

  /// Two-slide carousel with dash indicator
  Widget _buildSlider() {
    return Column(
      children: [
        SizedBox(
          height: 150,
          child: PageView(
            controller: _pageController,
            physics: const BouncingScrollPhysics(),
            children: [
              _buildAIMockCard(),
              _buildPreparationCard(),
            ],
          ),
        ),
        const SizedBox(height: 8),
        // Dash indicator row
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(2, (index) => _buildDash(index)),
        ),
      ],
    );
  }

  /// Single dash indicator
  Widget _buildDash(int index) {
    final bool isActive = _currentSlide == index;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      margin: const EdgeInsets.symmetric(horizontal: 4),
      width: isActive ? 20 : 14,
      height: 4,
      decoration: BoxDecoration(
        color: isActive ? Colors.blue : Colors.grey,
        borderRadius: BorderRadius.circular(2),
      ),
    );
  }

  /// Slide 1: AI Mock with background image
  Widget _buildAIMockCard() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        image: const DecorationImage(
          image: AssetImage('assets/aimock_bg.jpg'),
          fit: BoxFit.cover,
        ),
      ),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.black26,
          borderRadius: BorderRadius.circular(12),
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Test Your Knowledge with\nAI Mock Interview',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.black54,
              ),
            ),
            const SizedBox(height: 25),
            SizedBox(
              width: 100,
              height: 36,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const AiMockInterviewPage()),
                  );
                },
                child: const Text(
                  'Start',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Slide 2: Preparation with background image
  Widget _buildPreparationCard() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        image: const DecorationImage(
          image: AssetImage('assets/preparation_bg.jpg'),
          fit: BoxFit.cover,
        ),
      ),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.black26,
          borderRadius: BorderRadius.circular(12),
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Boost Your Preparation',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.black54,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Access study materials, practice questions, and expert tips.',
              style: TextStyle(
                fontSize: 14,
                color: Colors.black38,
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: 100,
              height: 36,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const PreparationPage()),
                  );
                },
                child: const Text(
                  'Start',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Performance overview helper
  Widget _buildOverviewItem(String value, String label) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            fontSize: 12,
            color: Colors.black54,
          ),
        ),
      ],
    );
  }

  /// No-activity placeholders
  List<Widget> _buildNoActivityPlaceholder() {
    final rounds = [
      {"name": "Aptitude & Verbal Round", "color": Colors.orange},
      {"name": "Technical Round", "color": Colors.blue},
      {"name": "Managerial Round", "color": Colors.green},
      {"name": "Hr Round", "color": Colors.purple},
    ];
    return List.generate(rounds.length, (index) {
      final round = rounds[index];
      final color = round["color"] as Color;
      final name = round["name"] as String;

      return Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          children: [
            CircleAvatar(
              radius: 18,
              backgroundColor: color.withOpacity(0.2),
              child: Text(
                (index + 1).toString(),
                style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    "0 Question",
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.white70,
                    ),
                  ),
                ],
              ),
            ),
            Text(
              "0/0",
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ],
        ),
      );
    });
  }
}
