import 'package:flutter/material.dart';
import 'loginpage.dart';

class OnboardingPage extends StatefulWidget {
  const OnboardingPage({Key? key}) : super(key: key);

  @override
  State<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends State<OnboardingPage> {
  final PageController _pageController = PageController();
  int _currentIndex = 0;

  // Slides data: background images, titles, descriptions
  final List<Map<String, String>> _slides = [
    {
      'bg': 'assets/onboarding1.png',
      'title': 'Get Ready to Ace Your Interviews',
      'description':
      'Our app is here to guide you through every step of the interview preparation process with confidence and ease. Let\'s get started!'
    },
    {
      'bg': 'assets/onboarding2.png',
      'title': 'Prepare with Real-Life Simulations',
      'description':
      'Simulate HR, technical, and managerial rounds to practice and improve with realistic, role-specific questions tailored to your dream job.'
    },
    {
      'bg': 'assets/onboarding3.png',
      'title': 'Track Your Progress, Improve Faster',
      'description':
      'Our goal is to ensure that you have everything you need to feel comfortable, confident, and ready to make an impact.'
    },
  ];

  @override
  void initState() {
    super.initState();
    _pageController.addListener(() {
      setState(() {
        _currentIndex = _pageController.page?.round() ?? 0;
      });
    });
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  // Skip => jump to last slide
  void _onSkip() {
    _pageController.animateToPage(
      _slides.length - 1,
      duration: const Duration(milliseconds: 400),
      curve: Curves.easeInOut,
    );
  }

  // Next or Done => if last slide, navigate away or show next page
  void _onNext() {
    if (_currentIndex < _slides.length - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeInOut,
      );
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const LoginPage()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Stack(
          children: [
            // PageView for slides
            PageView.builder(
              controller: _pageController,
              itemCount: _slides.length,
              physics: const BouncingScrollPhysics(),
              itemBuilder: (context, index) {
                final slide = _slides[index];
                return _buildSlide(
                  bgPath: slide['bg']!,
                  title: slide['title'] ?? '',
                  description: slide['description'] ?? '',
                );
              },
            ),

            // Bottom bar: Skip (except last slide), dot indicators, Next/Done
            Positioned(
              left: 0,
              right: 0,
              bottom: 20,
              child: Row(
                children: [
                  // Hide Skip button only on the last slide
                  if (_currentIndex < _slides.length - 1)
                    TextButton(
                      onPressed: _onSkip,
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                      ),
                      child: const Text(
                        'Skip',
                        style: TextStyle(color: Colors.black54),
                      ),
                    )
                  else
                    const SizedBox(width: 70), // Maintain alignment when hidden

                  // Dot indicators
                  Expanded(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(
                        _slides.length,
                            (dotIndex) => Container(
                          margin: const EdgeInsets.symmetric(horizontal: 3),
                          width: 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: _currentIndex == dotIndex
                                ? Colors.black87
                                : Colors.black26,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                    ),
                  ),

                  // Next / Done button
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: ElevatedButton(
                      onPressed: _onNext,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.black,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: Text(
                        _currentIndex == _slides.length - 1 ? 'Done' : 'Next',
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Build a single slide
  Widget _buildSlide({
    required String bgPath,
    required String title,
    required String description,
  }) {
    return Stack(
      children: [
        // Background image
        Positioned.fill(
          child: Image.asset(
            bgPath,
            fit: BoxFit.cover,
          ),
        ),
        // Text content at the bottom
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 40), // Some top spacing
              const Spacer(),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                description,
                style: const TextStyle(
                  fontSize: 14,
                  color: Colors.black54,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 80), // extra bottom spacing
            ],
          ),
        ),
      ],
    );
  }
}
