import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

import 'homedashboardpage.dart';
// Uncomment and update if you add the aptitude round page:
// import 'aptitude_round_page.dart';

class AptitudeRoundCompletePage extends StatefulWidget {
  final int score;
  final int totalQuestions;
  final String roundType;    // e.g. "Aptitude & Verbal Round"
  final String questionType; // e.g. "MCQ" or "Q/A"

  const AptitudeRoundCompletePage({
    Key? key,
    required this.score,
    required this.totalQuestions,
    required this.roundType,
    required this.questionType,
  }) : super(key: key);

  @override
  State<AptitudeRoundCompletePage> createState() => _AptitudeRoundCompletePageState();
}

class _AptitudeRoundCompletePageState extends State<AptitudeRoundCompletePage> {
  bool savingProgress = true;
  String saveMessage = "";

  @override
  void initState() {
    super.initState();
    saveProgress();
  }

  // Automatically called on page load to save progress.
  Future<void> saveProgress() async {
    // Retrieve the stored email from SharedPreferences.
    final prefs = await SharedPreferences.getInstance();
    final email = prefs.getString('email');

    if (email == null) {
      setState(() {
        savingProgress = false;
        saveMessage = "User not logged in.";
      });
      return;
    }

    final url = Uri.parse("http://192.168.185.251:80/API/save_progress.php");
    try {
      final response = await http.post(url, body: {
        "email_address": email,
        "round_type": widget.roundType,
        "question_type": widget.questionType,
        "score": widget.score.toString(),
        "total_questions": widget.totalQuestions.toString(),
      });
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          savingProgress = false;
          if (data["message"] != null) {
            saveMessage = data["message"];
          } else if (data["error"] != null) {
            saveMessage = data["error"];
          } else {
            saveMessage = "Progress saved with unknown response.";
          }
        });
      } else {
        setState(() {
          savingProgress = false;
          saveMessage = "Error saving progress: ${response.statusCode}";
        });
      }
    } catch (e) {
      setState(() {
        savingProgress = false;
        saveMessage = "Exception saving progress: $e";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Omitting the AppBar for a full-screen look.
      body: Stack(
        children: [
          // Full-screen background image (optional).
          SizedBox.expand(
            child: Image.asset(
              'assets/Loginbg.png', // Replace with your background asset.
              fit: BoxFit.cover,
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
              child: SizedBox(
                height: MediaQuery.of(context).size.height - 40,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(height: 20),
                    const Text(
                      "Aptitude Round",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 16),
                    // Big green check circle.
                    Container(
                      width: 120,
                      height: 120,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.green,
                      ),
                      child: const Icon(
                        Icons.check,
                        size: 60,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 16),
                    // Score display.
                    Text(
                      "SCORE: ${widget.score}/${widget.totalQuestions}",
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 8),
                    // Congratulatory message.
                    const Text(
                      "🎉 Successfully Completed!",
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.black87,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    // Tips or message.
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      margin: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Text(
                        "You're on the right track.\nA little more practice will boost your confidence and improve your scores.\n\nTIPS:\nReview concepts like percentages and logical reasoning for better results.",
                        style: TextStyle(fontSize: 14, color: Colors.black87),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(height: 20),
                    // Display saving message or progress.
                    savingProgress
                        ? const CircularProgressIndicator()
                        : Text(
                      saveMessage,
                      style: const TextStyle(fontSize: 16, color: Colors.green),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 20),
                    // Retake the Round button (update onPressed if adding the round page).
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.black,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        onPressed: () {
                          // Uncomment and update if you want to retake the round.
                          // Navigator.pushReplacement(
                          //   context,
                          //   MaterialPageRoute(builder: (context) => AptitudeRoundPage(difficulty: 'easy')),
                          // );
                        },
                        child: const Text(
                          'Retake the Round',
                          style: TextStyle(color: Colors.white, fontSize: 16),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    // Go to Home button.
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        onPressed: () {
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(builder: (context) => const HomeAndDashboardPage()),
                          );
                        },
                        child: const Text(
                          'Go to Home',
                          style: TextStyle(color: Colors.white, fontSize: 16),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
