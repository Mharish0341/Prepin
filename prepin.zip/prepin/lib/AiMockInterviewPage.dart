import 'package:flutter/material.dart';
import 'package:prepin/preparation.dart';
import 'package:prepin/profilepage.dart';
import 'package:prepin/technical_round_mcq_page.dart';
import 'package:prepin/technical_round_qa_page.dart';
import 'homedashboardpage.dart';
import 'aptitude_round_page.dart';
import 'hr_round_page.dart';
import 'managerial_round_page.dart';

class AiMockInterviewPage extends StatefulWidget {
  const AiMockInterviewPage({Key? key}) : super(key: key);
  @override
  State<AiMockInterviewPage> createState() => _AiMockInterviewPageState();
}

class _AiMockInterviewPageState extends State<AiMockInterviewPage> {
  final List<String> _roundTypes = [
    'Aptitude & Verbal Round',
    'Technical Round',
    'Managerial Round',
    'HR Interview',
  ];
  final List<String> _difficulties = ['Easy', 'Medium', 'Hard'];
  final List<String> _jobRoles = [
    'Data Analyst/Scientist',
    'Full Stack Developer',
    'Network/System Administrator',
    'Cybersecurity Specialist',
  ];
  final List<String> _questionTypes = ['MCQ', 'Q/A'];

  String? _selectedRoundType;
  String? _selectedDifficulty;
  String? _selectedJobRole;
  String? _selectedQuestionType;

  // TextEditingControllers (if needed)
  final TextEditingController _roundTypeController = TextEditingController();
  final TextEditingController _difficultyController = TextEditingController();
  final TextEditingController _jobRoleController = TextEditingController();
  final TextEditingController _questionTypeController = TextEditingController();

  int _currentIndex = 2;

  Future<bool> _onWillPop() async {
    // When back is pressed, navigate to the HomeAndDashboardPage
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => const HomeAndDashboardPage()),
          (Route<dynamic> route) => false,
    );
    return false;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        extendBody: true,
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => const HomeAndDashboardPage()),
                    (Route<dynamic> route) => false,
              );
            },
          ),
          centerTitle: true,
          title: const Text(
            'AI Mock Interview',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black87),
          ),
        ),
        body: Stack(
          children: [
            SizedBox.expand(
              child: Image.asset('assets/insidebg.png', fit: BoxFit.cover),
            ),
            SafeArea(
              top: false,
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: SizedBox(
                  height: MediaQuery.of(context).size.height,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Center(
                        child: Container(
                          width: double.infinity,
                          margin: const EdgeInsets.symmetric(horizontal: 16.0),
                          padding: const EdgeInsets.all(16.0),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.85),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              DropdownButtonFormField<String>(
                                dropdownColor: Colors.white,
                                decoration: _buildInputDecoration('Round Type'),
                                value: _selectedRoundType,
                                items: _roundTypes.map((round) {
                                  return DropdownMenuItem<String>(
                                    value: round,
                                    child: Text(round),
                                  );
                                }).toList(),
                                onChanged: (value) {
                                  setState(() {
                                    _selectedRoundType = value;
                                    _roundTypeController.text = value ?? '';
                                    // Reset question type if not technical
                                    if (_selectedRoundType != 'Technical Round') {
                                      _selectedQuestionType = null;
                                      _questionTypeController.clear();
                                    }
                                  });
                                },
                                hint: const Text('Choose Interview Round'),
                              ),
                              const SizedBox(height: 16),
                              DropdownButtonFormField<String>(
                                dropdownColor: Colors.white,
                                decoration: _buildInputDecoration('Difficulty'),
                                value: _selectedDifficulty,
                                items: _difficulties.map((diff) {
                                  return DropdownMenuItem<String>(
                                    value: diff,
                                    child: Text(diff),
                                  );
                                }).toList(),
                                onChanged: (value) {
                                  setState(() {
                                    _selectedDifficulty = value;
                                    _difficultyController.text = value ?? '';
                                  });
                                },
                                hint: const Text('Pick Difficulty Level'),
                              ),
                              const SizedBox(height: 16),
                              DropdownButtonFormField<String>(
                                dropdownColor: Colors.white,
                                decoration: _buildInputDecoration('Job Role'),
                                value: _selectedJobRole,
                                items: _jobRoles.map((job) {
                                  return DropdownMenuItem<String>(
                                    value: job,
                                    child: Text(job),
                                  );
                                }).toList(),
                                onChanged: (value) {
                                  setState(() {
                                    _selectedJobRole = value;
                                    _jobRoleController.text = value ?? '';
                                  });
                                },
                                hint: const Text('Choose Your Job'),
                              ),
                              const SizedBox(height: 16),
                              // Show MCQ/Q/A only if user selected Technical Round
                              if (_selectedRoundType == 'Technical Round') ...[
                                DropdownButtonFormField<String>(
                                  dropdownColor: Colors.white,
                                  decoration: _buildInputDecoration('Question Type'),
                                  value: _selectedQuestionType,
                                  items: _questionTypes.map((qType) {
                                    return DropdownMenuItem<String>(
                                      value: qType,
                                      child: Text(qType),
                                    );
                                  }).toList(),
                                  onChanged: (value) {
                                    setState(() {
                                      _selectedQuestionType = value;
                                      _questionTypeController.text = value ?? '';
                                    });
                                  },
                                  hint: const Text('Choose MCQ or Q/A'),
                                ),
                                const SizedBox(height: 16),
                              ],
                              SizedBox(
                                width: double.infinity,
                                height: 48,
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.black,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8.0),
                                    ),
                                  ),
                                  onPressed: () {
                                    // Validate required fields
                                    if (_selectedRoundType == null ||
                                        _selectedDifficulty == null ||
                                        _selectedJobRole == null ||
                                        (_selectedRoundType == 'Technical Round' &&
                                            _selectedQuestionType == null)) {
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(content: Text('Please fill out all required fields.')),
                                      );
                                      return;
                                    }

                                    // Navigate based on selected round
                                    if (_selectedRoundType == 'Aptitude & Verbal Round') {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => AptitudeRoundPage(
                                            difficulty: _selectedDifficulty!.toLowerCase(),
                                          ),
                                        ),
                                      );
                                    } else if (_selectedRoundType == 'Technical Round') {
                                      if (_selectedQuestionType == 'MCQ') {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) => TechnicalRoundMCQPage(
                                              difficulty: _selectedDifficulty!,
                                              jobRole: _selectedJobRole!,
                                            ),
                                          ),
                                        );
                                      } else if (_selectedQuestionType == 'Q/A') {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) => TechnicalRoundQAPage(
                                              difficulty: _selectedDifficulty!,
                                              jobRole: _selectedJobRole!,
                                            ),
                                          ),
                                        );
                                      }
                                    } else if (_selectedRoundType == 'Managerial Round') {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => ManagerialRoundPage(
                                            difficulty: _selectedDifficulty!.toLowerCase(),
                                            jobRole: _selectedJobRole!,
                                          ),
                                        ),
                                      );
                                    } else if (_selectedRoundType == 'HR Interview') {
                                      // Instead of navigating, show a "Coming Soon" dialog with a white background
                                      showDialog(
                                        context: context,
                                        builder: (context) {
                                          return AlertDialog(
                                            backgroundColor: Colors.white,
                                            title: const Text('Coming Soon'),
                                            content: const Text('HR Interview round will be available soon.'),
                                            actions: [
                                              TextButton(
                                                onPressed: () => Navigator.of(context).pop(),
                                                child: const Text('OK'),
                                              ),
                                            ],
                                          );
                                        },
                                      );
                                    }
                                  },
                                  child: const Text(
                                    'Submit',
                                    style: TextStyle(color: Colors.white, fontSize: 16),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
        bottomNavigationBar: BottomNavigationBar(
          backgroundColor: Colors.white,
          type: BottomNavigationBarType.fixed,
          currentIndex: _currentIndex,
          selectedItemColor: Colors.blue,
          unselectedItemColor: Colors.black,
          onTap: (index) {
            setState(() {
              _currentIndex = index;
            });
            if (index == 0) {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => const HomeAndDashboardPage()),
                    (Route<dynamic> route) => false,
              );
            } else if (index == 1) {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const PreparationPage()),
              );
            } else if (index == 2) {
              // Already on AI Mock Interview page
            } else if (index == 3) {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const ProfilePage()),
              );
            }
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home_outlined), label: 'Home'),
            BottomNavigationBarItem(icon: Icon(Icons.menu_book_outlined), label: 'Preparation'),
            BottomNavigationBarItem(icon: Icon(Icons.smart_toy_outlined), label: 'AI Mock'),
            BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: 'Profile'),
          ],
        ),
      ),
    );
  }

  InputDecoration _buildInputDecoration(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.black87),
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.0)),
    );
  }
}
