import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

// If you have a separate ExplanationPage file, import it here.
// Otherwise, remove or adjust these imports as needed.
import 'ExplanationPage.dart';

class TechnicalMCQQuestionPage extends StatefulWidget {
  final int questionNumber;       // e.g. 1..25
  final int totalQuestions;
  final String topic;             // e.g. "technical_mcq"
  final String difficulty;        // e.g. "easy", "medium", "hard"
  final String jobRole;           // e.g. "Full Stack Developer"
  final Map<String, dynamic>? initialResponse;
  final Function(String selected, String correct, Map<String, dynamic> questionData)
  onAnswered;
  final VoidCallback onNext;
  final VoidCallback onPrevious;

  const TechnicalMCQQuestionPage({
    Key? key,
    required this.questionNumber,
    required this.totalQuestions,
    required this.topic,
    required this.difficulty,
    required this.jobRole,
    this.initialResponse,
    required this.onAnswered,
    required this.onNext,
    required this.onPrevious,
  }) : super(key: key);

  @override
  State<TechnicalMCQQuestionPage> createState() =>
      _TechnicalMCQQuestionPageState();
}

class _TechnicalMCQQuestionPageState extends State<TechnicalMCQQuestionPage> {
  bool isLoading = true;

  /// Cleaned question text (with no leftover "A) B) ..." lines).
  String questionText = "";

  /// List of multiple-choice options, each like "A) Something".
  List<String> options = [];

  /// The correct answer (like "C"), stripped of any trailing asterisks.
  String correctAnswer = "";

  /// Explanation text for the question.
  String explanation = "";

  /// Whether the user has chosen an option yet.
  bool answered = false;

  /// Whether the user pressed "Done" to reveal correct/wrong answers.
  bool submitted = false;

  /// The letter the user selected, e.g. "A", "B", etc.
  String? selectedOption;

  @override
  void initState() {
    super.initState();
    // Restore any previously selected option if we have a stored response.
    if (widget.initialResponse != null) {
      selectedOption = widget.initialResponse!['selected'];
      answered = selectedOption != null;
    }
    _fetchQuestion();
  }

  /// Fetch the question from your Flask server's /generate_mcq endpoint.
  Future<void> _fetchQuestion() async {
    setState(() => isLoading = true);

    final url = Uri.parse(
      "http://192.168.185.251:5001/generate_mcq?"
          "difficulty=${Uri.encodeComponent(widget.difficulty)}"
          "&job_role=${Uri.encodeComponent(widget.jobRole)}"
          "&question_number=${widget.questionNumber}",
    );

    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        // Possibly contains something like "**Question 1:** A) A) lines"
        final rawQuestion = data["question_text"] ?? "No question available";
        final rawCorrect = data["correct_answer"] ?? "";
        explanation = data["explanation"] ?? "";

        // 1) Remove any leading "Question X" or "**Question X:**"
        final withoutPrefix = _removeQuestionPrefix(rawQuestion);

        // 2) Remove trailing or embedded "**" from the question text
        final cleanedQuestion = _removeStars(withoutPrefix);

        // 3) Extract question portion + options from multi-line text
        final extracted = _extractQuestionAndOptions(cleanedQuestion);
        questionText = extracted['question'];
        options = extracted['options'];

        // 4) Remove stars from the correct answer, e.g. "C**" => "C"
        correctAnswer = _removeStars(rawCorrect);

        setState(() => isLoading = false);
      } else {
        setState(() {
          questionText =
          "Error: Failed to load question. Code: ${response.statusCode}";
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        questionText = "Error: $e";
        isLoading = false;
      });
    }
  }

  /// Removes any leading "Question X:" or "**Question X:**" if present.
  String _removeQuestionPrefix(String text) {
    final pattern = RegExp(r'^\**Question\s*\d+:?\**\s*', caseSensitive: false);
    return text.replaceFirst(pattern, '').trim();
  }

  /// Removes all sequences of asterisks from the text.
  /// e.g. "**Question" => "Question", "C**" => "C"
  String _removeStars(String text) {
    return text.replaceAll(RegExp(r'\*+'), '').trim();
  }

  /// Splits out options in the format:
  ///   A) ...
  ///   B) ...
  ///   C) ...
  ///   D) ...
  /// from the multi-line text, leaving the question portion behind.
  Map<String, dynamic> _extractQuestionAndOptions(String fullText) {
    // This pattern matches lines that START with "A) ", "B) ", "C) ", or "D) "
    // ^ => start of line
    // [A-D]\) => "A)", "B)", "C)", or "D)"
    // \s => at least one space
    // .* => the rest of that line
    // $ => end of line
    // multiLine: true => ^ and $ match the start/end of each line
    final optionPattern = RegExp(r'^[A-D]\)\s.*$', multiLine: true);

    // Gather all lines that match the pattern
    final matches = optionPattern
        .allMatches(fullText)
        .map((m) => m.group(0)!.trim())
        .toList();

    // Remove those lines from the question text
    String questionPortion = fullText;
    for (var match in matches) {
      questionPortion = questionPortion.replaceFirst(match, '');
    }
    questionPortion = questionPortion.trim();

    return {
      'question': questionPortion,
      'options': matches,
    };
  }

  /// Called when the user taps an option
  void _selectOption(String optionText) {
    // The letter is everything before ")", e.g. "A" from "A) Some text"
    final letter = optionText.split(")")[0].trim();
    setState(() {
      selectedOption = letter;
      answered = true;
    });
    widget.onAnswered(selectedOption!, correctAnswer, {
      "question": questionText,
      "options": options,
      "correct_answer": correctAnswer,
      "explanation": explanation,
      "topic": widget.topic,
    });
  }

  /// Mark the question as done => reveal correct/wrong
  void _markDone() {
    setState(() {
      submitted = true;
    });
  }

  /// Return the background color for each option container
  Color getOptionColor(String letter) {
    if (!submitted) {
      // If not yet submitted, highlight only the selected one in green
      return (selectedOption == letter)
          ? Colors.green
          : Colors.white.withOpacity(0.9);
    } else {
      // After submission, highlight the correct answer in green,
      // and if the user selected a wrong answer, highlight it in red
      final correctLetter = correctAnswer.split(")")[0].trim();
      if (letter == correctLetter) {
        return Colors.green; // correct
      } else if (letter == selectedOption && letter != correctLetter) {
        return Colors.red; // wrong
      } else {
        return Colors.white.withOpacity(0.9);
      }
    }
  }

  /// Return the text color based on the background color
  Color getTextColor(String letter) {
    final bgColor = getOptionColor(letter);
    if (bgColor == Colors.green || bgColor == Colors.red) {
      return Colors.white;
    }
    return Colors.black87;
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Background image (make sure 'assets/Loginbg.png' is declared in pubspec.yaml)
        SizedBox.expand(
          child: Image.asset(
            'assets/Loginbg.png',
            fit: BoxFit.cover,
          ),
        ),
        SafeArea(
          child: isLoading
              ? const Center(child: CircularProgressIndicator())
              : SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(
              horizontal: 16.0,
              vertical: 20.0,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 80),
                // Display question number
                Center(
                  child: Text(
                    'Question ${widget.questionNumber}',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                // Display the question portion
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.9),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    questionText,
                    style: const TextStyle(
                      fontSize: 16,
                      color: Colors.black87,
                    ),
                  ),
                ),
                // Display MCQ options
                Column(
                  children: List.generate(options.length, (index) {
                    final optionText = options[index];
                    final letter = optionText.split(")")[0].trim();

                    return GestureDetector(
                      onTap: submitted
                          ? null
                          : () {
                        _selectOption(optionText);
                      },
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        margin: const EdgeInsets.only(bottom: 8),
                        decoration: BoxDecoration(
                          color: getOptionColor(letter),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          optionText,
                          style: TextStyle(
                            fontSize: 16,
                            color: getTextColor(letter),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    );
                  }),
                ),
                const SizedBox(height: 20),
                // If not submitted, show the "Done" button
                if (!submitted)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.black,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                        ),
                        onPressed:
                        (selectedOption == null) ? null : _markDone,
                        child: const Text(
                          'Done',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ],
                  )
                else
                // Once submitted, show correct answer & explanation
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        "Correct Answer: $correctAnswer",
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.green,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                            ),
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => ExplanationPage(
                                    explanation: explanation,
                                    onContinue: widget.onNext,
                                  ),
                                ),
                              );
                            },
                            child: const Text(
                              'Explanation',
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.black,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                            ),
                            onPressed: widget.onNext,
                            child: Text(
                              widget.questionNumber ==
                                  widget.totalQuestions
                                  ? 'Submit'
                                  : 'Next',
                              style: const TextStyle(color: Colors.white),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
