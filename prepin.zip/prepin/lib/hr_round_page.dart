import 'package:flutter/material.dart';
import 'homedashboardpage.dart';
import 'hr_round_complete_page.dart'; // We'll define this next

class HRRoundPage extends StatefulWidget {
  const HRRoundPage({Key? key}) : super(key: key);

  @override
  State<HRRoundPage> createState() => _HRRoundPageState();
}

class _HRRoundPageState extends State<HRRoundPage> {
  // Example questions for HR Round
  final List<String> _questions = [
    'Tell me about yourself and your career goals.',
    'How do you handle conflicts with colleagues?',
  ];

  // Track the current question index
  int _currentIndex = 0;

  // Controllers for each question's answer and real-time feedback
  late List<TextEditingController> _answerControllers;
  late List<TextEditingController> _feedbackControllers;

  @override
  void initState() {
    super.initState();
    // One answer + one feedback controller per question
    _answerControllers = List.generate(_questions.length, (_) => TextEditingController());
    _feedbackControllers = List.generate(_questions.length, (_) => TextEditingController());
  }

  @override
  Widget build(BuildContext context) {
    final questionText = _questions[_currentIndex];
    final bool isLastQuestion = _currentIndex == _questions.length - 1;

    return Scaffold(
      extendBodyBehindAppBar: true,
      // Transparent AppBar with two-line, centered title
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        // Back arrow to Home
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => const HomeAndDashboardPage()),
            );
          },
        ),
        centerTitle: true,
        title: Column(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Text(
              'AI Mock Interview',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            SizedBox(height: 6),
            Text(
              'HR Round',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.normal,
                color: Colors.black87,
              ),
            ),
          ],
        ),
      ),

      // Full-screen background + scrollable content
      body: Stack(
        children: [
          // Background image
          SizedBox.expand(
            child: Image.asset(
              'assets/insidebg.png', // Replace with your background
              fit: BoxFit.cover,
            ),
          ),
          SafeArea(
            top: false,
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
              child: SizedBox(
                // Occupies the remaining screen height
                height: MediaQuery.of(context).size.height - 40,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Extra spacing to push content further down
                    const SizedBox(height: 120),

                    // Question label
                    Text(
                      'Question ${_currentIndex + 1}',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 8),

                    // Question container
                    Container(
                      padding: const EdgeInsets.all(16),
                      margin: const EdgeInsets.only(bottom: 16),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        questionText,
                        style: const TextStyle(fontSize: 14, color: Colors.black87),
                      ),
                    ),

                    // Answer label
                    const Text(
                      'Answer',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 6),

                    // Answer text field
                    Container(
                      padding: const EdgeInsets.all(12),
                      margin: const EdgeInsets.only(bottom: 16),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: TextField(
                        controller: _answerControllers[_currentIndex],
                        maxLines: 5,
                        decoration: const InputDecoration(
                          hintText: 'Transcribe of your answer...',
                          border: InputBorder.none,
                        ),
                        style: const TextStyle(fontSize: 14, color: Colors.black87),
                      ),
                    ),

                    // Real-time feedback label
                    const Text(
                      'Real-time Feedback',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 6),

                    // Feedback text field
                    Container(
                      padding: const EdgeInsets.all(12),
                      margin: const EdgeInsets.only(bottom: 16),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: TextField(
                        controller: _feedbackControllers[_currentIndex],
                        maxLines: 3,
                        decoration: const InputDecoration(
                          hintText: 'Type real-time feedback...',
                          border: InputBorder.none,
                        ),
                        style: const TextStyle(fontSize: 14, color: Colors.black87),
                      ),
                    ),

                    // Spacer to push the row to the bottom
                    const Spacer(),

                    // Navigation row: mic center, Next/Submit on right
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // No button on left, small placeholder
                        const SizedBox(width: 8),

                        // Mic button in center
                        FloatingActionButton(
                          onPressed: () {
                            // Placeholder for voice input
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Voice input not implemented.')),
                            );
                          },
                          backgroundColor: Colors.blue,
                          child: const Icon(Icons.mic, color: Colors.white),
                        ),

                        // Next or Submit button (right)
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.black,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8.0),
                            ),
                          ),
                          onPressed: () {
                            if (_currentIndex < _questions.length - 1) {
                              setState(() {
                                _currentIndex++;
                              });
                            } else {
                              // Submit: navigate to completion page
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => HRRoundCompletePage(
                                    answers: _answerControllers.map((c) => c.text).toList(),
                                    feedbacks: _feedbackControllers.map((c) => c.text).toList(),
                                  ),
                                ),
                              );
                            }
                          },
                          child: Text(
                            _currentIndex < _questions.length - 1 ? 'Next' : 'Submit',
                            style: const TextStyle(color: Colors.white, fontSize: 16),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
