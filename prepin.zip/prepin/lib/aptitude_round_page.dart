import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'AiMockInterviewPage.dart';
import 'ExplanationPage.dart';
import 'aptitude_round_complete_page.dart';

class AptitudeRoundPage extends StatefulWidget {
  final String difficulty; // "easy", "medium", or "hard"
  const AptitudeRoundPage({Key? key, required this.difficulty}) : super(key: key);

  @override
  State<AptitudeRoundPage> createState() => _AptitudeRoundPageState();
}

class _AptitudeRoundPageState extends State<AptitudeRoundPage> {
  final PageController _pageController = PageController();
  static const int totalQuestions = 50; // 25 aptitude + 25 verbal reasoning
  List<Map<String, dynamic>?> responses =
  List<Map<String, dynamic>?>.filled(totalQuestions, null);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Make the body appear behind the AppBar
      extendBodyBehindAppBar: true,
      // Transparent AppBar with back arrow
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        // The back arrow
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const AiMockInterviewPage()),
                  (Route<dynamic> route) => false,
            );
          },
        ),
        // Center the title text
        centerTitle: true,
        title: const Text(
          'Aptitude & Verbal Round',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
      ),
      body: PageView.builder(
        controller: _pageController,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: totalQuestions,
        itemBuilder: (context, index) {
          final questionNumber = index + 1;
          // For questions 1..25 => "aptitude"; for 26..50 => "verbal reasoning"
          final computedTopic = (questionNumber <= 25) ? "aptitude" : "verbal reasoning";
          return QuestionPage(
            questionNumber: questionNumber,
            totalQuestions: totalQuestions,
            topic: computedTopic,
            difficulty: widget.difficulty,
            initialResponse: responses[index],
            onAnswered: (selected, correct, questionData) {
              responses[index] = {
                'selected': selected,
                'correct': correct,
                'questionData': questionData,
              };
            },
            onNext: () {
              if (index < totalQuestions - 1) {
                // Move to next question
                _pageController.nextPage(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.ease,
                );
              } else {
                // All questions done => compute final score
                int score = 0;
                for (final response in responses) {
                  if (response != null) {
                    final correctOption =
                    response['correct'].toString().split(")")[0].trim();
                    if (response['selected'] == correctOption) {
                      score++;
                    }
                  }
                }
                // Navigate to completion page
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AptitudeRoundCompletePage(
                      score: score,
                      totalQuestions: totalQuestions,
                      roundType: "Aptitude & Verbal Round",
                      questionType: "MCQ", // or "Q/A"
                    ),
                  ),
                );
              }
            },
            // We have no Previous button in this scenario
            onPrevious: () {},
          );
        },
      ),
    );
  }
}

class QuestionPage extends StatefulWidget {
  final int questionNumber;
  final int totalQuestions;
  final String topic;      // "aptitude" or "verbal reasoning"
  final String difficulty; // "easy", "medium", or "hard"
  final Map<String, dynamic>? initialResponse;
  final Function(String selected, String correct, Map<String, dynamic> questionData) onAnswered;
  final VoidCallback onNext;
  final VoidCallback onPrevious; // Not used

  const QuestionPage({
    Key? key,
    required this.questionNumber,
    required this.totalQuestions,
    required this.topic,
    required this.difficulty,
    this.initialResponse,
    required this.onAnswered,
    required this.onNext,
    required this.onPrevious,
  }) : super(key: key);

  @override
  State<QuestionPage> createState() => _QuestionPageState();
}

class _QuestionPageState extends State<QuestionPage> {
  bool isLoading = true;
  String questionText = "";
  List<String> options = [];
  String correctAnswer = "";
  String explanation = "";
  bool answered = false;
  bool submitted = false;
  String? selectedOption;

  @override
  void initState() {
    super.initState();
    if (widget.initialResponse != null) {
      selectedOption = widget.initialResponse!['selected'];
      answered = selectedOption != null;
    }
    _fetchQuestion();
  }

  Future<void> _fetchQuestion() async {
    setState(() => isLoading = true);
    final url = Uri.parse(
      "http://192.168.185.251:5000/api/question?topic=${widget.topic}&difficulty=${widget.difficulty}&question_number=${widget.questionNumber}",
    );
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          questionText = data['question'] ?? "No question available";
          options = data['options'] != null ? List<String>.from(data['options']) : [];
          correctAnswer = data['correct_answer'] ?? "";
          explanation = data['explanation'] ?? "";
          isLoading = false;
        });
      } else {
        setState(() {
          questionText = "Error: Failed to load question.";
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        questionText = "Error: $e";
        isLoading = false;
      });
    }
  }

  void _selectOption(String option) {
    setState(() {
      selectedOption = option.split(")")[0].trim();
      answered = true;
    });
    widget.onAnswered(selectedOption!, correctAnswer, {
      "question": questionText,
      "options": options,
      "correct_answer": correctAnswer,
      "explanation": explanation,
      "topic": widget.topic,
    });
  }

  void _markDone() {
    setState(() {
      submitted = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Background image
        SizedBox.expand(
          child: Image.asset(
            'assets/Loginbg.png',
            fit: BoxFit.cover,
          ),
        ),
        SafeArea(
          child: isLoading
              ? const Center(child: CircularProgressIndicator())
              : SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Extra space to accommodate the AppBar
                const SizedBox(height: 80),
                // Question Number
                Center(
                  child: Text(
                    'Question ${widget.questionNumber}',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                // Question text
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.9),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    questionText,
                    style: const TextStyle(fontSize: 16, color: Colors.black87),
                  ),
                ),
                // Options
                Column(
                  children: List.generate(options.length, (index) {
                    final optionText = options[index];
                    final optionLabel = optionText.split(")")[0].trim();

                    // Check if this option is correct
                    final isCorrectOption = (optionLabel == correctAnswer.split(")")[0].trim());

                    // Check if this option was chosen
                    final isSelectedOption = (optionLabel == selectedOption);

                    // Decide the background color based on 'submitted' and correctness
                    Color optionColor = Colors.white.withOpacity(0.9);
                    if (!submitted) {
                      // Before pressing "Done", we can highlight the chosen option in some color
                      if (isSelectedOption) {
                        optionColor = Colors.blue;
                      }
                    } else {
                      // Once submitted: highlight correct in green, wrong chosen in red
                      if (isCorrectOption) {
                        optionColor = Colors.green;
                      } else if (isSelectedOption && !isCorrectOption) {
                        optionColor = Colors.red;
                      }
                    }

                    // Decide text color
                    final textColor = (optionColor == Colors.green || optionColor == Colors.red || optionColor == Colors.blue)
                        ? Colors.white
                        : Colors.black87;

                    return GestureDetector(
                      onTap: submitted ? null : () => _selectOption(optionText),
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        margin: const EdgeInsets.only(bottom: 8),
                        decoration: BoxDecoration(
                          color: optionColor,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          optionText,
                          style: TextStyle(
                            fontSize: 16,
                            color: textColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    );
                  }),
                ),
                const SizedBox(height: 20),
                // If not submitted, show "Done" button
                if (!submitted)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.black,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                        ),
                        onPressed: (selectedOption == null) ? null : _markDone,
                        child: const Text(
                          'Done',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                // If submitted, show correct answer label + "Explanation" + "Next"
                if (submitted)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        "Correct Answer: $correctAnswer",
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.green,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                            ),
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => ExplanationPage(
                                    explanation: explanation,
                                    onContinue: widget.onNext,
                                  ),
                                ),
                              );
                            },
                            child: const Text(
                              'Explanation',
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.black,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                            ),
                            onPressed: widget.onNext,
                            child: Text(
                              widget.questionNumber == widget.totalQuestions
                                  ? 'Submit'
                                  : 'Next',
                              style: const TextStyle(color: Colors.white),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
