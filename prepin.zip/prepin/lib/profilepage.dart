import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'package:prepin/signup.dart';
import 'editprofillepage.dart';
import 'historypage.dart';
import 'homedashboardpage.dart';
import 'preparation.dart';
import 'AiMockInterviewPage.dart';
import 'loginpage.dart';
import 'profilepage.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  // For bottom nav, profile is index 3
  final int _currentIndex = 3;

  // Controllers for user data
  final TextEditingController _nameController =
  TextEditingController(text: 'User name');
  final TextEditingController _emailController = TextEditingController(text: '');
  final TextEditingController _phoneController = TextEditingController(text: '');

  // Variables for avatar image handling
  File? _avatarImageFile;
  String? _avatarUrl; // The full URL of the user's current avatar from the server

  // Image picker instance
  final ImagePicker _picker = ImagePicker();

  // Base URL for the server (adjust as needed)
  final String _baseUrl = "http://192.168.185.251:80/API/";

  // Intercept back navigation so that we navigate to the Home page instead
  Future<bool> _onWillPop() async {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const HomeAndDashboardPage()),
    );
    return false;
  }

  @override
  void initState() {
    super.initState();
    _loadUserEmail();
  }

  // Load the user email from SharedPreferences and then fetch user info
  Future<void> _loadUserEmail() async {
    final prefs = await SharedPreferences.getInstance();
    final email = prefs.getString('email') ?? '';
    setState(() {
      _emailController.text = email;
    });
    if (email.isNotEmpty) {
      _fetchUserInfo();
    }
  }

  // Fetch user info (username, email_address, phone_number, avatar) from the backend
  Future<void> _fetchUserInfo() async {
    final response = await http.get(
      Uri.parse("${_baseUrl}get_user.php?email_address=${_emailController.text}"),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      setState(() {
        if (data["username"] != null) {
          _nameController.text = data["username"];
        }
        if (data["email_address"] != null) {
          _emailController.text = data["email_address"];
        }
        // Set default phone number if null or empty
        if (data["phone_number"] != null &&
            data["phone_number"].toString().trim().isNotEmpty) {
          _phoneController.text = data["phone_number"];
        } else {
          _phoneController.text = "+01 000 000 000";
        }
        if (data["avatar"] != null) {
          String avatarPath = data["avatar"];
          // If the returned path is relative, prepend the base URL
          if (!avatarPath.startsWith("http")) {
            avatarPath = _baseUrl + avatarPath;
          }
          _avatarUrl = avatarPath;
        }
      });
    } else {
      print("Error fetching user info: ${response.statusCode}");
    }
  }

  // Let the user pick an image from their gallery and then upload it
  Future<void> _pickAndUploadImage() async {
    final XFile? pickedFile =
    await _picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (pickedFile != null) {
      setState(() {
        _avatarImageFile = File(pickedFile.path);
      });
      await _uploadAvatar(_avatarImageFile!);
    }
  }

  // Upload the avatar image to the server using a multipart request
  Future<void> _uploadAvatar(File imageFile) async {
    final uri = Uri.parse("${_baseUrl}update_avatar.php");
    final request = http.MultipartRequest("POST", uri);
    request.fields['email_address'] = _emailController.text;
    request.files
        .add(await http.MultipartFile.fromPath("avatar", imageFile.path));

    final response = await request.send();
    if (response.statusCode == 200) {
      final resBody = await response.stream.bytesToString();
      final data = jsonDecode(resBody);
      setState(() {
        if (data["avatar"] != null) {
          String newAvatar = data["avatar"];
          if (!newAvatar.startsWith("http")) {
            newAvatar = _baseUrl + newAvatar;
          }
          _avatarUrl = newAvatar;
        }
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(data["message"] ?? "Avatar updated.")),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Failed to update avatar.")),
      );
    }
  }

  // Logout function: remove email from SharedPreferences and navigate to LoginPage
  Future<void> _logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('email');
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const LoginPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          // Back arrow navigates back to Home
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => const HomeAndDashboardPage()),
              );
            },
          ),
          centerTitle: true,
          title: const Text(
            '',
            style:
            TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87),
          ),
        ),
        body: Stack(
          children: [
        // Full-screen background image
        SizedBox.expand(
        child: Image.asset(
          'assets/insidebg.png',
          fit: BoxFit.cover,
        ),
      ),
      // Scrollable content
      SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(
          children: [
            const SizedBox(height: 120),
            // Avatar with edit icon
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.grey.shade300,
                    image: DecorationImage(
                      image: _avatarImageFile != null
                          ? FileImage(_avatarImageFile!)
                          : (_avatarUrl != null
                          ? NetworkImage(_avatarUrl!)
                          : const AssetImage('assets/avatar.png')
                      as ImageProvider),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: Container(
                    width: 28,
                    height: 28,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                    ),
                    child: IconButton(
                      icon: const Icon(Icons.edit, size: 16, color: Colors.black),
                      padding: EdgeInsets.zero,
                      onPressed: _pickAndUploadImage,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            // User Info Section
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Column(
                children: [
                  // User name
                  TextField(
                    controller: _nameController,
                    readOnly: true,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                  // Email and phone in one line
                  TextField(
                    controller: _emailController,
                    readOnly: true,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 14, color: Colors.black54),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.zero,
                      suffixIcon: Padding(
                        padding: const EdgeInsets.only(right: 16.0),
                        child: Text(
                          ' | ${_phoneController.text}',
                          style: const TextStyle(fontSize: 14, color: Colors.black54),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  // Edit Profile Information Button
                  Container(
                    width: double.infinity,
                    margin: const EdgeInsets.only(bottom: 12),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: TextButton.icon(
                      onPressed: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) => EditProfilePage(email: _emailController.text)),
                        );
                      },
                      icon: const Icon(Icons.person_outline, color: Colors.black),
                      label: const Text(
                        'Edit profile information',
                        style: TextStyle(fontSize: 14, color: Colors.black),
                      ),
                    ),
                  ),
                  // History of Mock Interviews Button
                  Container(
                    width: double.infinity,
                    margin: const EdgeInsets.only(bottom: 12),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: TextButton.icon(
                      onPressed: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (context) => const HistoryPage()),
                        );
                      },
                      icon: const Icon(Icons.history, color: Colors.black),
                      label: const Text(
                        'History of mock interviews',
                        style: TextStyle(fontSize: 14, color: Colors.black),
                      ),
                    ),
                  ),
                  const SizedBox(height: 40),
                  // Delete Account Button with confirmation pop-up
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton(
                      onPressed: () {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              backgroundColor: Colors.white,
                              title: const Text(
                                'Confirm Delete Account',
                                style: TextStyle(color: Colors.black),
                              ),
                              content: const Text(
                                'Are you sure you want to delete your account?',
                                style: TextStyle(color: Colors.black87),
                              ),
                              actions: [
                                TextButton(
                                  onPressed: () {
                                    Navigator.of(context).pop(); // Close the dialog
                                  },
                                  child: const Text(
                                    'Cancel',
                                    style: TextStyle(color: Colors.blue),
                                  ),
                                ),
                                TextButton(
                                  onPressed: () {
                                    // Delete account action: for now, navigate to SignUpPage.
                                    Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(builder: (context) => const SignUpPage()),
                                    );
                                  },
                                  child: const Text(
                                    'Delete',
                                    style: TextStyle(color: Colors.red),
                                  ),
                                ),
                              ],
                            );
                          },
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: const Text('Delete Account',
                          style: TextStyle(color: Colors.white, fontSize: 16)),
                    ),
                  ),
                  const SizedBox(height: 12),
                  // Log Out Button
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton(
                      onPressed: _logout,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: const Text('Log out',
                          style: TextStyle(color: Colors.white, fontSize: 16)),
                    ),
                  ),
                  const SizedBox(height: 30),
                ],
              ),
            ),
          ],
        ),
      ),
      ],
    ),

    // Bottom Navigation Bar is still present; remove if not needed.
    bottomNavigationBar: _buildBottomNavBar(),
    ),
    );
  }

  // Build Bottom Navigation Bar (remove if not needed)
  Widget _buildBottomNavBar() {
    return BottomNavigationBar(
      backgroundColor: Colors.white,
      type: BottomNavigationBarType.fixed,
      currentIndex: _currentIndex,
      selectedItemColor: Colors.blue,
      unselectedItemColor: Colors.black,
      onTap: (index) {
        if (index == 0) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const HomeAndDashboardPage()),
          );
        } else if (index == 1) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const PreparationPage()),
          );
        } else if (index == 2) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const AiMockInterviewPage()),
          );
        } else if (index == 3) {
          // Already on Profile
        }
      },
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home_outlined), label: 'Home'),
        BottomNavigationBarItem(icon: Icon(Icons.menu_book_outlined), label: 'Preparation'),
        BottomNavigationBarItem(icon: Icon(Icons.smart_toy_outlined), label: 'AI Mock'),
        BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: 'Profile'),
      ],
    );
  }
}
