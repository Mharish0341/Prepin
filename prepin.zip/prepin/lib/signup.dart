import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'homedashboardpage.dart';
import 'loginpage.dart';

class SignUpPage extends StatefulWidget {
  const SignUpPage({Key? key}) : super(key: key);

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
  TextEditingController();
  final TextEditingController _otpController = TextEditingController();

  bool _isObscurePass1 = true;
  bool _isObscurePass2 = true;

  bool _isRegistered = false;
  bool _otpSent = false;
  bool _otpVerified = false;
  bool _otpInvalid = false;

  // Registration API: registers the user
  Future<void> _registerUser() async {
    final email = _emailController.text.trim();
    final password = _passwordController.text;
    final confirmPassword = _confirmPasswordController.text;

    // Replace with your registration API endpoint URL
    final url = Uri.parse('http://192.168.185.251:80/API/signup.php');

    try {
      final response = await http.post(url, body: {
        'email_address': email,
        'password': password,
        'confirm_password': confirmPassword,
      });

      final data = json.decode(response.body);
      if (data['message'] == 'User registered successfully.') {
        setState(() {
          _isRegistered = true;
        });
        // Automatically send OTP after successful registration.
        _sendOtp();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(data['message'])),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Registration error. Please try again.')),
      );
    }
  }

  // OTP Sending API: sends OTP to the email address
  Future<void> _sendOtp() async {
    final email = _emailController.text.trim();
    // Replace with your OTP sending API endpoint URL
    final url = Uri.parse('http://192.168.204.251:80/API/forgot_password.php');

    try {
      final response = await http.post(url, body: {
        'email_address': email,
      });

      final data = json.decode(response.body);
      if (data['message'] == 'OTP sent to your email.') {
        setState(() {
          _otpSent = true;
          _otpInvalid = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('OTP sent to your email.')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(data['message'])),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Error sending OTP. Please try again.')),
      );
    }
  }

  // OTP Verification API: verifies the OTP entered by the user
  Future<void> _verifyOtp() async {
    final email = _emailController.text.trim();
    final otp = _otpController.text.trim();
    // Replace with your OTP verification API endpoint URL
    final url = Uri.parse('http://192.168.204.251:80/API/verify_otp.php');

    try {
      final response = await http.post(url, body: {
        'email_address': email,
        'otp': otp,
      });

      final data = json.decode(response.body);
      if (data['message'] ==
          'OTP verified successfully. Registration complete.' ||
          data['message'] ==
              'OTP verified successfully. Proceed to reset password.') {
        setState(() {
          _otpVerified = true;
          _otpInvalid = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text(
                  'OTP verified successfully. Please click Submit Registration.')),
        );
      } else {
        setState(() {
          _otpInvalid = true;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(data['message'])),
        );
      }
    } catch (e) {
      setState(() {
        _otpInvalid = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content:
            Text('OTP verification error. Please try again.')),
      );
    }
  }

  // Final submission after OTP is verified.
  void _submitRegistration() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
          builder: (context) => const HomeAndDashboardPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Get screen dimensions and check if the keyboard is open
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    final bool isKeyboardOpen = MediaQuery.of(context).viewInsets.bottom > 0;

    // Define dynamic spacing variables
    final headerSpacing = screenHeight * 0.05;
    final formHorizontalPadding = screenWidth * 0.06;
    final footerPadding = screenHeight * 0.03;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/Loginbg.png'), // background image
            fit: BoxFit.cover,
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child: ConstrainedBox(
              constraints: BoxConstraints(minHeight: screenHeight),
              child: IntrinsicHeight(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // Header Section
                    SizedBox(height: headerSpacing),
                    const Text(
                      'Sign In & Prepare Smarter',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    SizedBox(height: headerSpacing * 0.5),
                    // Display logo only if the keyboard is closed
                    if (!isKeyboardOpen)
                      Image.asset(
                        'assets/signinlogo.png',
                        width: 200,
                        height: 200,
                      )
                    else
                      SizedBox(height: headerSpacing),
                    SizedBox(height: headerSpacing),
                    // Form Section
                    Padding(
                      padding:
                      EdgeInsets.symmetric(horizontal: formHorizontalPadding),
                      child: Column(
                        children: [
                          // Email TextField
                          TextFormField(
                            controller: _emailController,
                            decoration: InputDecoration(
                              hintText: 'Email Address',
                              hintStyle: const TextStyle(color: Colors.grey),
                              filled: true,
                              fillColor: Colors.white,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8.0),
                                borderSide:
                                const BorderSide(color: Colors.grey),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8.0),
                                borderSide:
                                const BorderSide(color: Colors.grey),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8.0),
                                borderSide:
                                const BorderSide(color: Colors.grey),
                              ),
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 16.0,
                                vertical: 16.0,
                              ),
                            ),
                            keyboardType: TextInputType.emailAddress,
                          ),
                          const SizedBox(height: 16),
                          // Password TextField
                          TextFormField(
                            controller: _passwordController,
                            obscureText: _isObscurePass1,
                            decoration: InputDecoration(
                              hintText: 'Type a password',
                              hintStyle: const TextStyle(color: Colors.grey),
                              filled: true,
                              fillColor: Colors.white,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8.0),
                                borderSide:
                                const BorderSide(color: Colors.grey),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8.0),
                                borderSide:
                                const BorderSide(color: Colors.grey),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8.0),
                                borderSide:
                                const BorderSide(color: Colors.grey),
                              ),
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 16.0,
                                vertical: 16.0,
                              ),
                              suffixIcon: IconButton(
                                icon: Icon(
                                  _isObscurePass1
                                      ? Icons.visibility_off
                                      : Icons.visibility,
                                  color: Colors.grey,
                                ),
                                onPressed: () {
                                  setState(() {
                                    _isObscurePass1 = !_isObscurePass1;
                                  });
                                },
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),
                          // Re-Type Password TextField
                          TextFormField(
                            controller: _confirmPasswordController,
                            obscureText: _isObscurePass2,
                            decoration: InputDecoration(
                              hintText: 'Re-Type a password',
                              hintStyle: const TextStyle(color: Colors.grey),
                              filled: true,
                              fillColor: Colors.white,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8.0),
                                borderSide:
                                const BorderSide(color: Colors.grey),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8.0),
                                borderSide:
                                const BorderSide(color: Colors.grey),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8.0),
                                borderSide:
                                const BorderSide(color: Colors.grey),
                              ),
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 16.0,
                                vertical: 16.0,
                              ),
                              suffixIcon: IconButton(
                                icon: Icon(
                                  _isObscurePass2
                                      ? Icons.visibility_off
                                      : Icons.visibility,
                                  color: Colors.grey,
                                ),
                                onPressed: () {
                                  setState(() {
                                    _isObscurePass2 = !_isObscurePass2;
                                  });
                                },
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          // Conditional button & OTP field:
                          if (!_isRegistered)
                          // Registration Button
                            SizedBox(
                              width: double.infinity,
                              height: 48,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.black,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                ),
                                onPressed: _registerUser,
                                child: const Text(
                                  'Sign Up',
                                  style: TextStyle(
                                      color: Colors.white, fontSize: 16),
                                ),
                              ),
                            )
                          else if (_isRegistered && !_otpVerified)
                          // OTP Verification UI
                            Column(
                              children: [
                                TextFormField(
                                  controller: _otpController,
                                  decoration: InputDecoration(
                                    hintText: 'Enter OTP',
                                    hintStyle:
                                    const TextStyle(color: Colors.grey),
                                    filled: true,
                                    fillColor: Colors.white,
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8.0),
                                      borderSide:
                                      const BorderSide(color: Colors.grey),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8.0),
                                      borderSide:
                                      const BorderSide(color: Colors.grey),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8.0),
                                      borderSide:
                                      const BorderSide(color: Colors.grey),
                                    ),
                                    contentPadding:
                                    const EdgeInsets.symmetric(
                                      horizontal: 16.0,
                                      vertical: 16.0,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 16),
                                SizedBox(
                                  width: double.infinity,
                                  height: 48,
                                  child: ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.black,
                                      shape: RoundedRectangleBorder(
                                        borderRadius:
                                        BorderRadius.circular(8.0),
                                      ),
                                    ),
                                    onPressed: _verifyOtp,
                                    child: const Text(
                                      'Verify OTP',
                                      style: TextStyle(
                                          color: Colors.white, fontSize: 16),
                                    ),
                                  ),
                                ),
                                if (_otpInvalid)
                                  TextButton(
                                    onPressed: () {
                                      _sendOtp();
                                    },
                                    child: const Text('Resend OTP'),
                                  ),
                              ],
                            )
                          else if (_otpVerified)
                            // Final submission button after OTP verification
                              SizedBox(
                                width: double.infinity,
                                height: 48,
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.black,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8.0),
                                    ),
                                  ),
                                  onPressed: _submitRegistration,
                                  child: const Text(
                                    'Submit Registration',
                                    style: TextStyle(
                                        color: Colors.white, fontSize: 16),
                                  ),
                                ),
                              ),
                        ],
                      ),
                    ),
                    SizedBox(height: 100),
                    // Footer Section with link to LoginPage
                    Padding(
                      padding: EdgeInsets.only(bottom: footerPadding),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text(
                            'Already have an account? ',
                            style: TextStyle(color: Colors.black54),
                          ),
                          InkWell(
                            onTap: () {
                              Navigator.pop(context);
                            },
                            child: const Text(
                              'Login here',
                              style: TextStyle(
                                color: Colors.blue,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
