import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'AiMockInterviewPage.dart';
import 'technical_mcq_question_page.dart';  // Our separate question widget
import 'technical_round_mcq_complete_page.dart';

class TechnicalRoundMCQPage extends StatefulWidget {
  final String difficulty;
  final String jobRole;

  const TechnicalRoundMCQPage({
    Key? key,
    required this.difficulty,
    required this.jobRole,
  }) : super(key: key);

  @override
  State<TechnicalRoundMCQPage> createState() => _TechnicalRoundMCQPageState();
}

class _TechnicalRoundMCQPageState extends State<TechnicalRoundMCQPage> {
  final PageController _pageController = PageController();

  // Total number of questions in the technical MCQ round.
  static const int totalQuestions = 25;

  // We'll keep a list of user responses for all questions (25).
  List<Map<String, dynamic>?> responses =
  List<Map<String, dynamic>?>.filled(totalQuestions, null);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Make AppBar background transparent so the background image can show through.
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            // If user presses back, return to AiMockInterviewPage
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const AiMockInterviewPage()),
                  (Route<dynamic> route) => false,
            );
          },
        ),
        centerTitle: true,
        title: const Text(
          'Technical Round - MCQ',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
      ),
      body: PageView.builder(
        controller: _pageController,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: totalQuestions,
        itemBuilder: (context, index) {
          final questionNumber = index + 1;

          // Provide a topic value to satisfy the required parameter.
          final computedTopic = "technical_mcq";

          return TechnicalMCQQuestionPage(
            questionNumber: questionNumber,
            totalQuestions: totalQuestions,
            topic: computedTopic,  // <-- REQUIRED "topic" ARGUMENT
            difficulty: widget.difficulty,
            jobRole: widget.jobRole,

            // If we already answered this question, pass the stored response
            initialResponse: responses[index],

            // Callback to store the user's selection (so we can compute final score)
            onAnswered: (selected, correct, questionData) {
              responses[index] = {
                'selected': selected,
                'correct': correct,
                'questionData': questionData,
              };
            },

            // When the user moves to next question (or finishes)
            onNext: () {
              if (index < totalQuestions - 1) {
                // Move to the next question in the PageView
                _pageController.nextPage(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.ease,
                );
              } else {
                // Last question => compute final score
                int score = 0;
                for (final response in responses) {
                  if (response != null) {
                    // correct might be "C**", so we strip stars and compare letters only
                    final correctOption = response['correct']
                        .toString()
                        .replaceAll('*', '')
                        .split(")")[0]
                        .trim();
                    if (response['selected'] == correctOption) {
                      score++;
                    }
                  }
                }
                // Go to completion page
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => TechnicalRoundMCQCompletePage(
                      score: score,
                      totalQuestions: totalQuestions,
                      roundType: "Technical Round",
                      questionType: "MCQ",
                    ),
                  ),
                );
              }
            },

            // If you need a "Previous" button, handle it here
            onPrevious: () {},
          );
        },
      ),
    );
  }
}
