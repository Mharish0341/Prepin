import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'homedashboardpage.dart';
import 'managerial_round_page.dart';

class ManagerialRoundCompletePage extends StatefulWidget {
  final List<String> answers;
  final List<String> feedbacks;
  final double finalScore;
  final int totalQuestions;

  const ManagerialRoundCompletePage({
    Key? key,
    required this.answers,
    required this.feedbacks,
    required this.finalScore,
    required this.totalQuestions,
  }) : super(key: key);

  @override
  State<ManagerialRoundCompletePage> createState() => _ManagerialRoundCompletePageState();
}

class _ManagerialRoundCompletePageState extends State<ManagerialRoundCompletePage> {
  double? _storedScore;

  @override
  void initState() {
    super.initState();
    _submitProgress();
  }

  /// Submit progress to your PHP endpoint and store the final score.
  Future<void> _submitProgress() async {
    // Replace with actual email from storage if available.
    final userEmail = "testuser@example.com";
    final url = Uri.parse("http://192.168.185.251:80/API/save_progress.php");
    try {
      final response = await http.post(
        url,
        body: {
          'email_address': userEmail,
          'round_type': 'Managerial Round',
          'question_type': 'Q/A',
          'score': widget.finalScore.toString(),
          'total_questions': widget.totalQuestions.toString(),
          'questions_attended': widget.totalQuestions.toString(),
        },
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          _storedScore = widget.finalScore;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Progress saved successfully.")),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error saving progress: ${response.statusCode}")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Exception saving progress: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    String scoreDisplay = widget.finalScore.toStringAsFixed(2);
    return Scaffold(
      extendBodyBehindAppBar: true,
      // Transparent AppBar
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            // Return to Home
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => const HomeAndDashboardPage()),
            );
          },
        ),
        centerTitle: true,
        title: const Text(
          'Managerial Round',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
      ),
      body: Stack(
        children: [
          // Background
          SizedBox.expand(
            child: Image.asset('assets/insidebg.png', fit: BoxFit.cover),
          ),
          SafeArea(
            top: false,
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
              child: SizedBox(
                height: MediaQuery.of(context).size.height - 80,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(height: 30),
                    // Big green check
                    Container(
                      margin: const EdgeInsets.only(top: 40),
                      width: 120,
                      height: 120,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.green,
                      ),
                      child: const Icon(
                        Icons.check,
                        size: 60,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      '🎉 Successfully Completed!\nFinal Score: $scoreDisplay / ${widget.totalQuestions}',
                      style: const TextStyle(
                        fontSize: 16,
                        color: Colors.black87,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    // Display typed answers + feedback
                    Container(
                      width: double.infinity,
                      margin: const EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: SizedBox(
                        height: 180,
                        child: SingleChildScrollView(
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Your Answers:',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black87,
                                ),
                              ),
                              const SizedBox(height: 4),
                              for (int i = 0; i < widget.answers.length; i++)
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Q${i + 1} Answer:',
                                      style: const TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black87,
                                      ),
                                    ),
                                    Text(
                                      widget.answers[i].isEmpty
                                          ? 'No answer provided.'
                                          : widget.answers[i],
                                      style: const TextStyle(fontSize: 14, color: Colors.black87),
                                    ),
                                    const SizedBox(height: 6),
                                    Text(
                                      'Q${i + 1} Feedback:',
                                      style: const TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black87,
                                      ),
                                    ),
                                    Text(
                                      widget.feedbacks[i].isEmpty
                                          ? 'No feedback provided.'
                                          : widget.feedbacks[i],
                                      style: const TextStyle(fontSize: 14, color: Colors.black87),
                                    ),
                                    const SizedBox(height: 10),
                                  ],
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      margin: const EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Text(
                        'Great job! Continue refining your leadership and communication skills to excel in managerial roles. '
                            'Focus on empathy, clarity, and strategic thinking for best results.',
                        style: TextStyle(fontSize: 14, color: Colors.black87),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.black,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        onPressed: () {
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(builder: (context) => const ManagerialRoundPage(
                              difficulty: "easy",
                              jobRole: "IT Manager",
                            )),
                          );
                        },
                        child: const Text(
                          'Retake the Round',
                          style: TextStyle(color: Colors.white, fontSize: 16),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        onPressed: () async {
                          // Submit progress then navigate to Home
                          await _submitProgress();
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(builder: (context) => const HomeAndDashboardPage()),
                          );
                        },
                        child: const Text(
                          'Go to Home',
                          style: TextStyle(color: Colors.white, fontSize: 16),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
