import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:http/http.dart' as http;
import 'homedashboardpage.dart';
import 'managerial_round_complete_page.dart';

class ManagerialRoundPage extends StatefulWidget {
  final String difficulty;
  final String jobRole;

  const ManagerialRoundPage({
    Key? key,
    required this.difficulty,
    required this.jobRole,
  }) : super(key: key);

  @override
  State<ManagerialRoundPage> createState() => _ManagerialRoundPageState();
}

class _ManagerialRoundPageState extends State<ManagerialRoundPage> {
  // Now generate 10 questions one-by-one.
  final int totalQuestions = 10;
  int _currentIndex = 0;
  // We'll store each fetched question in its corresponding index.
  List<String> _questions = List.filled(10, '');

  late List<TextEditingController> _answerControllers;
  late List<TextEditingController> _feedbackControllers;
  // List to store the numeric score for each question.
  List<double> _scores = List.filled(10, 0.0);

  bool isLoading = true;

  // flutter_sound references
  final FlutterSoundRecorder _recorder = FlutterSoundRecorder();
  bool _isRecorderInitialized = false;
  bool _isRecording = false;
  String? _recordedFilePath;

  @override
  void initState() {
    super.initState();
    _answerControllers = List.generate(totalQuestions, (_) => TextEditingController());
    _feedbackControllers = List.generate(totalQuestions, (_) => TextEditingController());
    _questions = List.filled(totalQuestions, '');
    _scores = List.filled(totalQuestions, 0.0);
    // Fetch only the first question initially.
    _fetchQuestion();
    _initRecorder();
  }

  // Initialize the flutter_sound recorder.
  Future<void> _initRecorder() async {
    final status = await Permission.microphone.request();
    if (status != PermissionStatus.granted) {
      throw Exception('Microphone permission not granted');
    }
    await _recorder.openRecorder();
    _isRecorderInitialized = true;
  }

  @override
  void dispose() {
    _recorder.closeRecorder();
    super.dispose();
  }

  /// Fetch a single question from the Flask endpoint using question_number = _currentIndex + 1.
  Future<void> _fetchQuestion() async {
    setState(() => isLoading = true);
    final questionNumber = _currentIndex + 1;
    final url = Uri.parse(
        "http://192.168.185.251:5002/generate_managerial?"
            "difficulty=${Uri.encodeComponent(widget.difficulty)}"
            "&job_role=${Uri.encodeComponent(widget.jobRole)}"
            "&question_number=$questionNumber"
    );
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final fetchedQuestion = data["question_text"] ?? "No question available.";
        setState(() {
          _questions[_currentIndex] = fetchedQuestion;
        });
      } else {
        setState(() {
          _questions[_currentIndex] =
          "Error: question #$questionNumber (code ${response.statusCode})";
        });
      }
    } catch (e) {
      setState(() {
        _questions[_currentIndex] = "Error: question #$questionNumber => $e";
      });
    }
    setState(() {
      isLoading = false;
    });
  }

  /// Start or stop recording.
  Future<void> _toggleRecording() async {
    if (!_isRecorderInitialized) return;
    if (_isRecording) {
      // Stop recording.
      final path = await _recorder.stopRecorder();
      setState(() {
        _isRecording = false;
        _recordedFilePath = path;
      });
      if (_recordedFilePath != null) {
        await _handleAudioFlow(_recordedFilePath!);
      }
    } else {
      // Start recording: record to .m4a with AAC in an MP4 container.
      await _recorder.startRecorder(
        toFile: 'managerial_answer.m4a',
        codec: Codec.aacMP4,
      );
      setState(() {
        _isRecording = true;
        _recordedFilePath = null;
      });
    }
  }

  /// Once a recorded file is available, upload it, then transcribe and evaluate.
  Future<void> _handleAudioFlow(String filePath) async {
    // 1) Upload the audio to /transcribe_managerial.
    final transcribedText = await _uploadAudioForTranscription(filePath);
    if (transcribedText != null) {
      // Update the Answer field.
      setState(() {
        _answerControllers[_currentIndex].text = transcribedText;
      });
      // 2) Evaluate the transcribed text.
      final question = _questions[_currentIndex];
      final evalResult = await _evaluateAnswer(question, transcribedText);
      if (evalResult != null) {
        setState(() {
          _feedbackControllers[_currentIndex].text = evalResult['feedback'];
          _scores[_currentIndex] = evalResult['score'];
        });
      }
    }
  }

  /// Upload the audio file to /transcribe_managerial.
  Future<String?> _uploadAudioForTranscription(String filePath) async {
    final url = Uri.parse("http://192.168.255.251:5002/transcribe_managerial");
    try {
      final request = http.MultipartRequest('POST', url);
      request.files.add(await http.MultipartFile.fromPath('audio', filePath));
      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data["transcribed_text"] as String?;
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Transcription error: ${response.statusCode}")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Upload error: $e")),
      );
    }
    return null;
  }

  /// Evaluate the answer by calling /evaluate_managerial.
  /// Returns a Map with keys "score" (double) and "feedback" (String).
  Future<Map<String, dynamic>?> _evaluateAnswer(String question, String userAnswer) async {
    final url = Uri.parse("http://192.168.255.251:5002/evaluate_managerial");
    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: json.encode({
          "question": question,
          "answer": userAnswer,
        }),
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return {
          "score": (data["score"] ?? 0.0) as double,
          "feedback": data["feedback"] as String? ?? "No feedback",
        };
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Evaluate error: ${response.statusCode}")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Evaluate exception: $e")),
      );
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading || _questions[_currentIndex].isEmpty) {
      return Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const HomeAndDashboardPage()),
              );
            },
          ),
          centerTitle: true,
          title: const Text(
            'AI Mock Interview\nManagerial Round',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87),
          ),
        ),
        body: Stack(
          children: [
            SizedBox.expand(
              child: Image.asset('assets/insidebg.png', fit: BoxFit.cover),
            ),
            const Center(child: CircularProgressIndicator()),
          ],
        ),
      );
    }

    final bool isLastQuestion = _currentIndex == totalQuestions - 1;
    final String questionText = _questions[_currentIndex];

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => const HomeAndDashboardPage()),
            );
          },
        ),
        centerTitle: true,
        title: const Text(
          'AI Mock Interview\nManagerial Round',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87),
        ),
      ),
      body: Stack(
        children: [
          // Background
          SizedBox.expand(
            child: Image.asset('assets/insidebg.png', fit: BoxFit.cover),
          ),
          SafeArea(
            top: false,
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const SizedBox(height: 120),
                  Text(
                    'Question ${_currentIndex + 1} of $totalQuestions',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(16),
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      questionText,
                      style: const TextStyle(fontSize: 14, color: Colors.black87),
                    ),
                  ),
                  const Text(
                    'Answer',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.all(12),
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: TextField(
                      controller: _answerControllers[_currentIndex],
                      maxLines: 5,
                      decoration: const InputDecoration(
                        hintText: 'Transcribe your answer...',
                        border: InputBorder.none,
                      ),
                      style: const TextStyle(fontSize: 14, color: Colors.black87),
                    ),
                  ),
                  const Text(
                    'Real-time Feedback',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.all(12),
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: TextField(
                      controller: _feedbackControllers[_currentIndex],
                      maxLines: 3,
                      decoration: const InputDecoration(
                        hintText: 'Type real-time feedback or fetch from LLM...',
                        border: InputBorder.none,
                      ),
                      style: const TextStyle(fontSize: 14, color: Colors.black87),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const SizedBox(width: 80),
                      FloatingActionButton(
                        onPressed: _toggleRecording,
                        backgroundColor: _isRecording ? Colors.red : Colors.blue,
                        child: Icon(
                          _isRecording ? Icons.stop : Icons.mic,
                          color: Colors.white,
                        ),
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.black,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                        ),
                        onPressed: () async {
                          if (!isLastQuestion) {
                            // Save current question answer/feedback then fetch next question.
                            setState(() {
                              _currentIndex++;
                            });
                            await _fetchQuestion();
                          } else {
                            // On last question, navigate to completion page.
                            // Compute final score (sum of scores)
                            double finalScore = 0.0;
                            for (var s in _scores) {
                              finalScore += s;
                            }
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) => ManagerialRoundCompletePage(
                                  answers: _answerControllers.map((c) => c.text).toList(),
                                  feedbacks: _feedbackControllers.map((c) => c.text).toList(),
                                  finalScore: finalScore,
                                  totalQuestions: totalQuestions,
                                ),
                              ),
                            );
                          }
                        },
                        child: Text(
                          isLastQuestion ? 'Submit' : 'Next',
                          style: const TextStyle(color: Colors.white, fontSize: 16),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
