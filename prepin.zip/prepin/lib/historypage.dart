import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

// Import ProfilePage (for back navigation)
import 'profilepage.dart';

class HistoryPage extends StatefulWidget {
  const HistoryPage({Key? key}) : super(key: key);

  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  // Controller for the search bar.
  final TextEditingController _searchController = TextEditingController();

  // List of history rounds loaded from the backend.
  List<Map<String, dynamic>> _allRounds = [];
  List<Map<String, dynamic>> _filteredRounds = [];

  // Base URL for your API endpoint – adjust as needed.
  final String _baseUrl = "http://192.168.185.251:80/API/";

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_onSearchChanged);
    _fetchHistory();
  }

  @override
  void dispose() {
    _searchController.removeListener(_onSearchChanged);
    _searchController.dispose();
    super.dispose();
  }

  // Filter the list whenever the search query changes.
  void _onSearchChanged() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredRounds = _allRounds.where((round) {
        final roundType = round['round_type']?.toString().toLowerCase() ?? '';
        return roundType.contains(query);
      }).toList();
    });
  }

  // Fetch the progress history from your backend using email from SharedPreferences.
  Future<void> _fetchHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final email = prefs.getString('email') ?? '';
    if (email.isEmpty) {
      // If there's no email, do nothing (or show an error message).
      return;
    }
    final url = Uri.parse("$_baseUrl" + "get_progress.php?email_address=$email");
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data is List) {
          setState(() {
            _allRounds = List<Map<String, dynamic>>.from(data);
            _filteredRounds = List.from(_allRounds);
          });
        } else {
          setState(() {
            _allRounds = [];
            _filteredRounds = [];
          });
        }
      } else {
        debugPrint("Error fetching history: ${response.statusCode}");
      }
    } catch (e) {
      debugPrint("Exception while fetching history: $e");
    }
  }

  // Determine a color based on the round type.
  Color _getColorForRound(String roundType) {
    switch (roundType.toLowerCase()) {
      case 'aptitude & verbal round':
        return Colors.orange;
      case 'technical round':
        return Colors.blue;
      case 'managerial round':
        return Colors.green;
      case 'hr round':
        return Colors.purple;
      default:
        return Colors.grey;
    }
  }

  // Intercept the Android back button to navigate to ProfilePage.
  Future<bool> _onWillPop() async {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const ProfilePage()),
    );
    return false;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        extendBodyBehindAppBar: true,
        body: Stack(
          children: [
            // Full-screen background image.
            SizedBox.expand(
              child: Image.asset(
                'assets/insidebg.png',
                fit: BoxFit.cover,
              ),
            ),
            // Main content using a CustomScrollView.
            CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                // SliverAppBar with a back arrow and title.
                SliverAppBar(
                  backgroundColor: Colors.transparent,
                  expandedHeight: 100,
                  floating: false,
                  pinned: true,
                  leading: IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.black),
                    onPressed: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => const ProfilePage()),
                      );
                    },
                  ),
                  flexibleSpace: const FlexibleSpaceBar(
                    centerTitle: true,
                    title: Text(
                      'History',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                  ),
                ),
                // Search bar.
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 16),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: TextField(
                        controller: _searchController,
                        decoration: const InputDecoration(
                          prefixIcon: Icon(Icons.search, color: Colors.black54),
                          hintText: 'Search rounds...',
                          hintStyle: TextStyle(color: Colors.black54),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.all(12),
                        ),
                      ),
                    ),
                  ),
                ),
                // List of history cards.
                SliverList(
                  delegate: SliverChildBuilderDelegate(
                        (context, index) {
                      final item = _filteredRounds[index];
                      final roundType = item['round_type']?.toString() ?? 'Unknown';
                      final totalQs = item['total_questions']?.toString() ?? '0';
                      final score = item['score']?.toString() ?? '0';
                      final questionType = item['question_type']?.toString() ?? 'N/A';

                      // Combine total questions and question type.
                      final detailsLine = "$totalQs Questions • $questionType";
                      final color = _getColorForRound(roundType);

                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 6),
                        child: _buildHistoryCard(
                          roundNumber: index + 1,
                          roundName: roundType,
                          detailsLine: detailsLine,
                          score: "$score/$totalQs",
                          color: color,
                        ),
                      );
                    },
                    childCount: _filteredRounds.length,
                  ),
                ),
                // Extra space at the bottom.
                const SliverToBoxAdapter(child: SizedBox(height: 20)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // Build a single history card.
  Widget _buildHistoryCard({
    required int roundNumber,
    required String roundName,
    required String detailsLine,
    required String score,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.9),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade300,
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          // Circle with the round number.
          CircleAvatar(
            radius: 18,
            backgroundColor: color.withOpacity(0.2),
            child: Text(
              roundNumber.toString(),
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(width: 12),
          // Round details: round type on top, then details line.
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  roundName,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  detailsLine,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.black54,
                  ),
                ),
              ],
            ),
          ),
          // Score on the right.
          Text(
            score,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
