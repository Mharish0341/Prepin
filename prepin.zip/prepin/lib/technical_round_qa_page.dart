import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'homedashboardpage.dart';
import 'technical_round_qa_complete_page.dart';

class TechnicalRoundQAPage extends StatefulWidget {
  final String difficulty;
  final String jobRole;

  const TechnicalRoundQAPage({
    Key? key,
    required this.difficulty,
    required this.jobRole,
  }) : super(key: key);

  @override
  State<TechnicalRoundQAPage> createState() => _TechnicalRoundQAPageState();
}

class _TechnicalRoundQAPageState extends State<TechnicalRoundQAPage> {
  /// The current question number (1..8)
  int _currentQuestionNumber = 1;

  /// The question text and expected logic for the *current* question
  String questionText = "";
  String expectedLogic = "";

  /// Whether we are fetching the question from the server
  bool isLoading = true;

  /// The user’s typed code for the *current* question
  final TextEditingController _answerController = TextEditingController();

  /// The logged-in user’s email
  String? userEmail;

  /// Running total of scores for all answered questions
  double totalScore = 0.0;

  /// The maximum number of questions you want (8)
  final int maxQuestions = 8;

  @override
  void initState() {
    super.initState();
    _loadUserEmail();
    _fetchQuestion(_currentQuestionNumber);
  }

  /// Load user’s email from SharedPreferences
  Future<void> _loadUserEmail() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      userEmail = prefs.getString('email') ?? '';
    });
  }

  /// Fetch a single programming question for [questionNum] from your Flask endpoint
  Future<void> _fetchQuestion(int questionNum) async {
    setState(() => isLoading = true);

    final url = Uri.parse(
        "http://192.168.185.251:5001/generate_programming?"
            "difficulty=${Uri.encodeComponent(widget.difficulty.toLowerCase())}"
            "&job_role=${Uri.encodeComponent(widget.jobRole)}"
            "&question_number=$questionNum"
    );
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        final rawQuestion = data["question_text"] ?? "No question available";
        final rawExpected = data["expected_logic"] ?? "";

        setState(() {
          questionText = _cleanMarkdown(rawQuestion);
          expectedLogic = _cleanMarkdown(rawExpected);
          _answerController.clear(); // Clear old code each time
          isLoading = false;
        });
      } else {
        setState(() {
          questionText =
          "Error: Failed to load question #$questionNum (code ${response.statusCode}).";
          expectedLogic = "";
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        questionText = "Error: $e";
        expectedLogic = "";
        isLoading = false;
      });
    }
  }

  /// Clean up markdown (remove ###, backticks, etc.)
  String _cleanMarkdown(String text) {
    String cleaned = text.replaceAll('```', '');
    cleaned = cleaned.replaceAll(RegExp(r'^#+\s*', multiLine: true), '');
    return cleaned.trim();
  }

  /// Evaluate the user’s typed code for the *current* question
  Future<double> _evaluateAnswer() async {
    final userCode = _answerController.text;
    final evalUrl = Uri.parse(
        "http://192.168.255.251:5001/evaluate_code?"
            "question=${Uri.encodeComponent(questionText)}&"
            "user_code=${Uri.encodeComponent(userCode)}&"
            "expected_logic=${Uri.encodeComponent(expectedLogic)}"
    );
    try {
      final response = await http.get(evalUrl);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return (data["score_fraction"] ?? 0.0) as double;
      }
    } catch (e) {
      print("Error evaluating code for question #$_currentQuestionNumber: $e");
    }
    return 0.0;
  }

  /// Submit the final totalScore to the PHP endpoint
  Future<void> _submitScoreToServer() async {
    final phpUrl = "http://192.168.185.251:80/API/save_progress.php";
    final emailToUse =
    (userEmail != null && userEmail!.isNotEmpty) ? userEmail! : 'testuser@example.com';

    try {
      final response = await http.post(
        Uri.parse(phpUrl),
        body: {
          'email_address': emailToUse,
          'round_type': 'Technical Round',
          'question_type': 'Programming',
          'score': totalScore.toString(),
          'total_questions': maxQuestions.toString(),
          'questions_attended': maxQuestions.toString(),
        },
      );
      if (response.statusCode == 200) {
        print("Score stored: ${response.body}");
      } else {
        print("Error storing progress: ${response.statusCode}");
      }
    } catch (e) {
      print("Exception storing progress: $e");
    }
  }

  /// Called when user taps "Next" (or "Submit" if last question)
  Future<void> _handleNextOrSubmit() async {
    // 1) Evaluate the current question’s code
    final scoreFraction = await _evaluateAnswer();
    // 2) Add partial score to total
    setState(() {
      totalScore += scoreFraction;
    });

    // 3) If we are not on the last question, fetch the next question
    if (_currentQuestionNumber < maxQuestions) {
      setState(() {
        _currentQuestionNumber++;
      });
      await _fetchQuestion(_currentQuestionNumber);
    } else {
      // 4) If we are on the last question => store total & go to completion page
      await _submitScoreToServer();
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => TechnicalRoundQACompletePage(
            score: totalScore,
            totalQuestions: maxQuestions,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      // Show a loading spinner while fetching question
      return Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const HomeAndDashboardPage()),
              );
            },
          ),
          centerTitle: true,
          title: const Text(
            'Technical Round',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87),
          ),
        ),
        body: Stack(
          children: [
            SizedBox.expand(
              child: Image.asset('assets/insidebg.png', fit: BoxFit.cover),
            ),
            const Center(child: CircularProgressIndicator()),
          ],
        ),
      );
    }

    // Once loaded, show the question + answer
    final isLastQuestion = _currentQuestionNumber == maxQuestions;
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            // If user goes back, or forcibly leaves the round
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => const HomeAndDashboardPage()),
            );
          },
        ),
        centerTitle: true,
        title: const Text(
          'Technical Round',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87),
        ),
      ),
      body: Stack(
        children: [
          // Background
          SizedBox.expand(
            child: Image.asset('assets/insidebg.png', fit: BoxFit.cover),
          ),
          SafeArea(
            top: false,
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
              child: Column(
                children: [
                  const SizedBox(height: 80),
                  // "Question" box
                  Container(
                    width: double.infinity,
                    margin: const EdgeInsets.only(bottom: 16),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Question $_currentQuestionNumber of $maxQuestions',
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          questionText,
                          style: const TextStyle(fontSize: 14, color: Colors.black87),
                        ),
                      ],
                    ),
                  ),
                  // "Answer" box
                  Container(
                    width: double.infinity,
                    margin: const EdgeInsets.only(bottom: 16),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Answer',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                        const SizedBox(height: 8),
                        TextField(
                          controller: _answerController,
                          maxLines: 5,
                          decoration: const InputDecoration(
                            hintText: 'Type your code or answer here...',
                            border: InputBorder.none,
                          ),
                          style: const TextStyle(fontSize: 14, color: Colors.black87),
                        ),
                      ],
                    ),
                  ),
                  // Next or Submit
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.black,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                      ),
                      onPressed: _handleNextOrSubmit,
                      child: Text(
                        isLastQuestion ? 'Submit' : 'Next',
                        style: const TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
