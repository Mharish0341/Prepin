import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

import 'homedashboardpage.dart';

class TechnicalRoundMCQCompletePage extends StatefulWidget {
  final int score;
  final int totalQuestions;
  final String roundType;    // e.g. "Technical Round"
  final String questionType; // e.g. "MCQ"

  const TechnicalRoundMCQCompletePage({
    Key? key,
    required this.score,
    required this.totalQuestions,
    this.roundType = "Technical Round",
    this.questionType = "MCQ",
  }) : super(key: key);

  @override
  State<TechnicalRoundMCQCompletePage> createState() =>
      _TechnicalRoundMCQCompletePageState();
}

class _TechnicalRoundMCQCompletePageState
    extends State<TechnicalRoundMCQCompletePage> {
  bool savingProgress = true;
  String saveMessage = "";

  @override
  void initState() {
    super.initState();
    saveProgress();
  }

  Future<void> saveProgress() async {
    final prefs = await SharedPreferences.getInstance();
    final email = prefs.getString('email');

    if (email == null) {
      setState(() {
        savingProgress = false;
        saveMessage = "User not logged in.";
      });
      return;
    }

    // Adjust your actual URL for saving progress
    final url = Uri.parse("http://192.168.185.251:80/API/save_progress.php");
    try {
      final response = await http.post(url, body: {
        "email_address": email,
        "round_type": widget.roundType,
        "question_type": widget.questionType,
        "score": widget.score.toString(),
        "total_questions": widget.totalQuestions.toString(),
      });
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          savingProgress = false;
          if (data["message"] != null) {
            saveMessage = data["message"];
          } else if (data["error"] != null) {
            saveMessage = data["error"];
          } else {
            saveMessage = "Progress saved with unknown response.";
          }
        });
      } else {
        setState(() {
          savingProgress = false;
          saveMessage = "Error saving progress: ${response.statusCode}";
        });
      }
    } catch (e) {
      setState(() {
        savingProgress = false;
        saveMessage = "Exception saving progress: $e";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Omitting an AppBar for a full-screen look
      body: Stack(
        children: [
          SizedBox.expand(
            child: Image.asset(
              'assets/Loginbg.png', // Replace with your background asset
              fit: BoxFit.cover,
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
              child: SizedBox(
                height: MediaQuery.of(context).size.height - 40,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(height: 20),
                    const Text(
                      "Technical Round",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      width: 120,
                      height: 120,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.green,
                      ),
                      child: const Icon(
                        Icons.check,
                        size: 60,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      "SCORE: ${widget.score}/${widget.totalQuestions}",
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      "🎉 Successfully Completed!",
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.black87,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      margin: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Text(
                        "You're on the right track.\nA little more practice will boost your confidence and improve your scores.\n\n"
                            "TIPS:\nReview concurrency control, design patterns, and system architecture for better results in technical interviews.",
                        style: TextStyle(fontSize: 14, color: Colors.black87),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(height: 20),
                    savingProgress
                        ? const CircularProgressIndicator()
                        : Text(
                      saveMessage,
                      style: const TextStyle(
                          fontSize: 16, color: Colors.green),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.black,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        onPressed: () {
                          // If you want to retake the round, navigate to the relevant page
                          // For now, do nothing or implement your logic
                        },
                        child: const Text(
                          'Retake the Round',
                          style: TextStyle(color: Colors.white, fontSize: 16),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        onPressed: () {
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const HomeAndDashboardPage(),
                            ),
                          );
                        },
                        child: const Text(
                          'Go to Home',
                          style: TextStyle(color: Colors.white, fontSize: 16),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
