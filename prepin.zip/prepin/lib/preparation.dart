import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'homedashboardpage.dart';
import 'questionbank_page.dart';
import 'AiMockInterviewPage.dart';
import 'profilepage.dart';

class PreparationPage extends StatefulWidget {
  const PreparationPage({Key? key}) : super(key: key);

  @override
  State<PreparationPage> createState() => _PreparationPageState();
}

class _PreparationPageState extends State<PreparationPage> {
  int _selectedSegment = 0; // 0: Aptitude & Verbal, 1: Technical, 2: Managerial, 3: HR Interview
  int _currentIndex = 1;    // This page is index 1
  bool _isQnA = true;       // Only applies when Technical is selected

  final List<String> _segments = [
    'Aptitude & Verbal',
    'Technical',
    'Managerial',
    'HR Interview',
  ];

  // Fetched card data from backend
  List<dynamic> _cardList = [];
  bool _isLoading = false;
  String _errorMessage = '';

  // Search bar controller & query
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  // Endpoint for question_cards_db.php
  final Uri _cardsUrl =
  Uri.parse('http://192.168.185.251:80/API/question_cards_db.php');

  // Local images for known card titles
  final Map<String, String> _cardImages = {
    'Aptitude-Critical Thinking': 'assets/prep_aptitude.png',
    'Python': 'assets/prep_python.png',
    'C++': 'assets/prep_cpp.png',
    'Managerial Question': 'assets/prep_managerial.png',
  };

  // Convert selected segment to category string
  String getSelectedCategory() {
    switch (_selectedSegment) {
      case 0:
        return 'Aptitude & Verbal';
      case 1:
        return 'Technical';
      case 2:
        return 'Managerial';
      case 3:
        return 'HR Interview';
      default:
        return 'Aptitude & Verbal';
    }
  }

  // Convert toggle to question type string
  String getQuestionType() {
    return _isQnA ? 'Q/A' : 'MCQ';
  }

  // Filter the card list based on the search query
  List<dynamic> get _filteredCardList {
    if (_searchQuery.isEmpty) return _cardList;
    return _cardList.where((row) {
      final title = (row['card_title'] ?? '').toString().toLowerCase();
      return title.contains(_searchQuery.toLowerCase());
    }).toList();
  }

  Future<void> _fetchCardNames() async {
    final category = getSelectedCategory();
    final questionType =
    (category == 'Technical') ? getQuestionType() : '';

    setState(() {
      _isLoading = true;
      _errorMessage = '';
      _cardList.clear();
    });

    try {
      final response = await http.post(_cardsUrl, body: {
        'category': category,
        'question_type': questionType,
      });

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data is List) {
          setState(() {
            _cardList = data;
            _isLoading = false;
          });
        } else if (data is Map && data.containsKey('message')) {
          setState(() {
            _errorMessage = data['message'];
            _isLoading = false;
          });
        } else {
          setState(() {
            _errorMessage = 'Unknown response format.';
            _isLoading = false;
          });
        }
      } else {
        setState(() {
          _errorMessage = 'Server error: ${response.statusCode}';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Exception: $e';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    return WillPopScope(
      onWillPop: () async {
        _currentIndex = 0;
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => const HomeAndDashboardPage()),
              (Route<dynamic> route) => false,
        );
        return false;
      },
      child: Scaffold(
        body: Container(
          // Full background image
          decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/insidebg.png'),
              fit: BoxFit.cover,
            ),
          ),
          child: SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: SizedBox(
                height: screenHeight,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Column(
                    children: [
                      // Remove extra vertical space
                      const SizedBox(height: 0),
                      // Top row with back arrow and title
                      Row(
                        children: [
                          IconButton(
                            icon: const Icon(Icons.arrow_back, color: Colors.black),
                            onPressed: () {
                              _currentIndex = 0;
                              Navigator.pushAndRemoveUntil(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const HomeAndDashboardPage(),
                                ),
                                    (Route<dynamic> route) => false,
                              );
                            },
                          ),
                          Expanded(
                            child: Center(
                              child: Text(
                                'Preparation',
                                style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 48),
                        ],
                      ),
                      const SizedBox(height: 0),
                      // Segmented chips for category
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: List.generate(_segments.length, (index) {
                            final isSelected = _selectedSegment == index;
                            return Padding(
                              padding: const EdgeInsets.only(right: 8.0),
                              child: ChoiceChip(
                                label: Text(_segments[index]),
                                selected: isSelected,
                                selectedColor: Colors.blue.shade300,
                                onSelected: (selected) {
                                  setState(() {
                                    _selectedSegment = index;
                                  });
                                },
                                labelStyle: TextStyle(
                                  color: isSelected ? Colors.white : Colors.black,
                                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                                ),
                                backgroundColor: Colors.grey.shade200,
                              ),
                            );
                          }),
                        ),
                      ),
                      const SizedBox(height: 16),
                      // Q/A vs MCQ toggle for Technical only
                      if (_selectedSegment == 1)
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            TextButton(
                              onPressed: () => setState(() => _isQnA = true),
                              style: TextButton.styleFrom(
                                backgroundColor: _isQnA ? Colors.black : Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                  side: const BorderSide(color: Colors.black),
                                ),
                              ),
                              child: Text(
                                'Q/A',
                                style: TextStyle(
                                  color: _isQnA ? Colors.white : Colors.black,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            TextButton(
                              onPressed: () => setState(() => _isQnA = false),
                              style: TextButton.styleFrom(
                                backgroundColor: !_isQnA ? Colors.black : Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                  side: const BorderSide(color: Colors.black),
                                ),
                              ),
                              child: Text(
                                'MCQ',
                                style: TextStyle(
                                  color: !_isQnA ? Colors.white : Colors.black,
                                ),
                              ),
                            ),
                          ],
                        ),
                      const SizedBox(height: 16),
                      // Search bar for filtering card titles
                      TextField(
                        controller: _searchController,
                        decoration: InputDecoration(
                          hintText: 'Search card titles...',
                          prefixIcon: const Icon(Icons.search),
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                        ),
                        onChanged: (value) {
                          setState(() {
                            _searchQuery = value;
                          });
                        },
                      ),
                      const SizedBox(height: 16),
                      // Button to fetch card names
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.black,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                        ),
                        onPressed: _fetchCardNames,
                        child: const Text(
                          'Search',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                      const SizedBox(height: 16),
                      _isLoading
                          ? const CircularProgressIndicator()
                          : _errorMessage.isNotEmpty
                          ? Text(_errorMessage, style: const TextStyle(color: Colors.red))
                          : _buildCardList(),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
        // Unified bottom navigation bar using pushAndRemoveUntil for all items
        bottomNavigationBar:BottomNavigationBar(
          backgroundColor: Colors.white,
          type: BottomNavigationBarType.fixed,
          currentIndex: _currentIndex,
          selectedItemColor: Colors.blue,
          unselectedItemColor: Colors.black,
          onTap: (index) {
            setState(() {
              _currentIndex = index;
            });
            if (index == 0) {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => const HomeAndDashboardPage()),
                    (Route<dynamic> route) => false,
              );
            } else if (index == 1) {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => const PreparationPage()),
                    (Route<dynamic> route) => false,
              );
            } else if (index == 2) {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => const AiMockInterviewPage()),
                    (Route<dynamic> route) => false,
              );
            } else if (index == 3) {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => const ProfilePage()),
                    (Route<dynamic> route) => false,
              );
            }
          },
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.home_outlined),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.menu_book_outlined),
              label: 'Preparation',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.smart_toy_outlined),
              label: 'AI Mock',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person_outline),
              label: 'Profile',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCardList() {
    if (_cardList.isEmpty) {
      return const Text('No cards found for this category.');
    }
    final list = _filteredCardList;
    if (list.isEmpty) {
      return const Text('No matching cards for your search.');
    }
    return Expanded(
      child: ListView.builder(
        physics: const BouncingScrollPhysics(),
        itemCount: list.length,
        itemBuilder: (context, index) {
          final row = list[index];
          final cardTitle = row['card_title'] ?? 'Unknown Title';
          return _buildCardItem(cardTitle);
        },
      ),
    );
  }

  Widget _buildCardItem(String cardTitle) {
    final imagePath = _cardImages[cardTitle] ?? 'assets/prep_aptitude.png';
    final category = getSelectedCategory();
    final questionType = (category == 'Technical') ? getQuestionType() : '';

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      height: 140,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        image: DecorationImage(
          image: AssetImage(imagePath),
          fit: BoxFit.cover,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade300,
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        // Card text and button at the bottom
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Text(
              cardTitle,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 8),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => QuestionBankPage(
                      pageTitle: cardTitle,
                      category: category,
                      questionType: questionType,
                    ),
                  ),
                );
              },
              child: const Text(
                'View & Prepare',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
